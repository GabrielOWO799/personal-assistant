"""
API抓取器测试
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from api_scraper import APIScraper


def test_api_scraper_init():
    """测试初始化"""
    scraper = APIScraper()
    assert scraper is not None
    print("✅ 初始化测试通过")


def test_github_scraping():
    """测试GitHub API抓取"""
    scraper = APIScraper()
    results = scraper.scrape_github_trending(max_items=5)
    
    assert isinstance(results, list)
    print(f"✅ GitHub API抓取测试通过 (获取 {len(results)} 条)")
    
    if results:
        print(f"   示例: {results[0]['name']} - ⭐{results[0]['stars']}")


def test_github_trending():
    """测试GitHub Trending抓取"""
    scraper = APIScraper()
    results = scraper.scrape_github_daily_trending()
    
    assert isinstance(results, list)
    print(f"✅ GitHub Trending抓取测试通过 (获取 {len(results)} 条)")


def test_save_and_summary():
    """测试保存和摘要功能"""
    scraper = APIScraper()
    
    # 模拟数据
    scraper.data = [
        {
            'platform': 'GitHub',
            'name': 'awesome-ai-project',
            'stars': 1000,
            'category': 'AI'
        },
        {
            'platform': 'Product Hunt',
            'name': 'Cool AI App',
            'votes': 500,
            'category': 'AI'
        }
    ]
    
    # 测试保存
    json_path = scraper.save_to_json("test_api_data.json")
    assert os.path.exists(json_path)
    
    # 测试摘要
    summary = scraper.get_summary()
    assert summary['total_count'] == 2
    assert 'GitHub' in summary['platforms']
    
    print("✅ 保存和摘要测试通过")
    
    # 清理
    os.remove(json_path)


if __name__ == "__main__":
    print("开始测试 API抓取器...\n")
    
    test_api_scraper_init()
    test_github_scraping()
    test_github_trending()
    test_save_and_summary()
    
    print("\n🎉 所有测试通过！")
