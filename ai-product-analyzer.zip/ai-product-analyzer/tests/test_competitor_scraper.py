"""
竞品抓取器测试
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from competitor_scraper import CompetitorScraper


def test_scraper_init():
    """测试初始化"""
    scraper = CompetitorScraper()
    assert scraper is not None
    assert scraper.session is not None
    print("✅ 初始化测试通过")


def test_scrape_kickstarter():
    """测试Kickstarter抓取"""
    scraper = CompetitorScraper()
    results = scraper.scrape_kickstarter(keyword="AI toy", max_items=3)
    
    # 注意：实际抓取可能因网络或网站结构变化而失败
    # 这里只测试函数能正常运行
    assert isinstance(results, list)
    print(f"✅ Kickstarter抓取测试通过 (获取 {len(results)} 条)")


def test_scrape_indiegogo():
    """测试Indiegogo抓取"""
    scraper = CompetitorScraper()
    results = scraper.scrape_indiegogo(keyword="AI toy", max_items=3)
    
    assert isinstance(results, list)
    print(f"✅ Indiegogo抓取测试通过 (获取 {len(results)} 条)")


def test_scrape_36kr():
    """测试36氪抓取"""
    scraper = CompetitorScraper()
    results = scraper.scrape_36kr(keyword="AI硬件", max_items=3)
    
    assert isinstance(results, list)
    print(f"✅ 36氪抓取测试通过 (获取 {len(results)} 条)")


def test_save_and_summary():
    """测试保存和摘要功能"""
    scraper = CompetitorScraper()
    
    # 模拟数据
    scraper.data = [
        {
            'platform': 'Kickstarter',
            'name': 'Test Project 1',
            'description': 'Test description',
            'url': 'https://test.com/1',
            'category': 'AI Toy'
        },
        {
            'platform': 'Indiegogo',
            'name': 'Test Project 2',
            'description': 'Test description 2',
            'url': 'https://test.com/2',
            'category': 'AI Hardware'
        }
    ]
    
    # 测试保存JSON
    json_path = scraper.save_to_json("test_competitor.json")
    assert os.path.exists(json_path)
    
    # 测试保存CSV
    csv_path = scraper.save_to_csv("test_competitor.csv")
    assert os.path.exists(csv_path)
    
    # 测试摘要
    summary = scraper.get_summary()
    assert summary['total_count'] == 2
    assert 'Kickstarter' in summary['platforms']
    assert 'Indiegogo' in summary['platforms']
    
    print("✅ 保存和摘要测试通过")
    
    # 清理测试文件
    os.remove(json_path)
    os.remove(csv_path)


if __name__ == "__main__":
    print("开始测试 竞品抓取器...\n")
    
    test_scraper_init()
    test_scrape_kickstarter()
    test_scrape_indiegogo()
    test_scrape_36kr()
    test_save_and_summary()
    
    print("\n🎉 所有测试通过！")
    print("\n注意：实际网络抓取可能因网站反爬机制而受限")
    print("建议在实际使用时添加代理、请求头伪装等机制")
