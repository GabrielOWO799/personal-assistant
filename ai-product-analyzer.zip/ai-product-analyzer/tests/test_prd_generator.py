"""
PRD生成器测试
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from prd_generator import PRDGenerator


def test_prd_generation():
    """测试PRD生成"""
    generator = PRDGenerator()
    
    # 测试基本生成
    prd = generator.generate(
        product_name="测试产品",
        product_idea="一个帮助用户提高效率的AI工具",
        pm_name="测试PM"
    )
    
    # 验证关键内容
    assert "测试产品" in prd
    assert "产品需求文档" in prd
    assert "测试PM" in prd
    assert "产品概述" in prd
    assert "需求分析" in prd
    
    print("✅ PRD生成测试通过")
    return prd


def test_save_to_file():
    """测试保存文件"""
    generator = PRDGenerator()
    
    prd = generator.generate(
        product_name="文件测试产品",
        product_idea="测试文件保存功能"
    )
    
    filepath = generator.save_to_file(prd, "test_prd.md")
    
    # 验证文件存在
    assert os.path.exists(filepath)
    
    # 验证内容
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
        assert "文件测试产品" in content
    
    print(f"✅ 文件保存测试通过: {filepath}")
    
    # 清理测试文件
    os.remove(filepath)


def test_different_products():
    """测试不同产品类型"""
    generator = PRDGenerator()
    
    test_cases = [
        {
            "name": "AI图像生成器",
            "idea": "通过文字描述自动生成图片的AI工具"
        },
        {
            "name": "智能客服系统",
            "idea": "自动回复客户咨询的AI客服"
        },
        {
            "name": "数据分析平台",
            "idea": "帮助非技术人员快速分析数据的工具"
        }
    ]
    
    for case in test_cases:
        prd = generator.generate(
            product_name=case["name"],
            product_idea=case["idea"]
        )
        
        assert case["name"] in prd
        assert len(prd) > 1000  # 确保内容充实
        
        print(f"✅ {case['name']} 测试通过")


if __name__ == "__main__":
    print("开始测试 PRD生成器...\n")
    
    test_prd_generation()
    test_save_to_file()
    test_different_products()
    
    print("\n🎉 所有测试通过！")
