"""
Web界面 - 数据展示
简单的Flask应用展示竞品数据
"""

import json
import os
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from flask import Flask, render_template, jsonify
from src.analytics import AnalyticsGenerator

app = Flask(__name__)

# 加载数据
def load_latest_data():
    """加载最新数据文件"""
    import glob
    data_files = glob.glob("data/combined_competitor_data_*.json")
    if data_files:
        latest_file = max(data_files)
        with open(latest_file, 'r', encoding='utf-8') as f:
            return json.load(f)
    return []

@app.route('/')
def index():
    """首页"""
    data = load_latest_data()
    
    # 生成分析
    analytics = AnalyticsGenerator(data)
    analysis = analytics.generate_full_analysis()
    
    # 获取TOP项目
    top_projects = sorted(
        [p for p in data if 'stars' in p],
        key=lambda x: int(x.get('stars', 0)) if str(x.get('stars', '0')).isdigit() else 0,
        reverse=True
    )[:10]
    
    return render_template('index.html', 
                          data=data,
                          analysis=analysis,
                          top_projects=top_projects,
                          total_count=len(data))

@app.route('/api/data')
def api_data():
    """API接口 - 返回所有数据"""
    data = load_latest_data()
    return jsonify(data)

@app.route('/api/analysis')
def api_analysis():
    """API接口 - 返回分析结果"""
    data = load_latest_data()
    analytics = AnalyticsGenerator(data)
    return jsonify(analytics.generate_full_analysis())

if __name__ == '__main__':
    print("🌐 启动Web服务器...")
    print("访问地址: http://localhost:5000")
    app.run(host='0.0.0.0', port=5000, debug=False)
