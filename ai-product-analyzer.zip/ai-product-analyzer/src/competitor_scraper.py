"""
竞品数据抓取模块
自动抓取AI硬件/潮玩竞品信息
"""

import requests
import json
import re
import time
from datetime import datetime
from typing import List, Dict, Optional
from urllib.parse import urljoin, urlparse


class CompetitorScraper:
    """竞品数据抓取器"""
    
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        self.data = []
    
    def scrape_kickstarter(self, keyword: str = "AI toy", max_items: int = 10) -> List[Dict]:
        """
        抓取Kickstarter上的AI硬件/潮玩项目
        
        Args:
            keyword: 搜索关键词
            max_items: 最大抓取数量
            
        Returns:
            项目列表
        """
        results = []
        
        try:
            # Kickstarter搜索API
            url = f"https://www.kickstarter.com/discover/advanced"
            params = {
                'term': keyword,
                'sort': 'newest',
                'seed': int(time.time())
            }
            
            response = self.session.get(url, params=params, timeout=10)
            
            if response.status_code == 200:
                # 解析HTML提取项目信息
                html = response.text
                
                # 提取项目卡片（简化版，实际可能需要更复杂的解析）
                projects = self._parse_kickstarter_html(html)
                
                for project in projects[:max_items]:
                    results.append({
                        'platform': 'Kickstarter',
                        'name': project.get('name', ''),
                        'description': project.get('description', ''),
                        'url': project.get('url', ''),
                        'funding_goal': project.get('goal', ''),
                        'pledged': project.get('pledged', ''),
                        'backers': project.get('backers', ''),
                        'days_left': project.get('days_left', ''),
                        'category': 'AI Hardware/Toy',
                        'scraped_at': datetime.now().isoformat()
                    })
                    
        except Exception as e:
            print(f"Kickstarter抓取失败: {e}")
            
        return results
    
    def scrape_indiegogo(self, keyword: str = "AI toy", max_items: int = 10) -> List[Dict]:
        """
        抓取Indiegogo上的AI硬件/潮玩项目
        
        Args:
            keyword: 搜索关键词
            max_items: 最大抓取数量
            
        Returns:
            项目列表
        """
        results = []
        
        try:
            # Indiegogo API
            url = "https://www.indiegogo.com/private_api/discover"
            params = {
                'q': keyword,
                'sort': 'new',
                'per_page': max_items
            }
            
            response = self.session.get(url, params=params, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                campaigns = data.get('response', {}).get('campaigns', [])
                
                for campaign in campaigns[:max_items]:
                    results.append({
                        'platform': 'Indiegogo',
                        'name': campaign.get('title', ''),
                        'description': campaign.get('tagline', ''),
                        'url': f"https://www.indiegogo.com{campaign.get('url', '')}",
                        'funding_goal': campaign.get('goal', {}).get('amount', ''),
                        'pledged': campaign.get('funds_raised', {}).get('amount', ''),
                        'backers': campaign.get('contributions_count', ''),
                        'percent_funded': campaign.get('percent_funded', ''),
                        'category': 'AI Hardware/Toy',
                        'scraped_at': datetime.now().isoformat()
                    })
                    
        except Exception as e:
            print(f"Indiegogo抓取失败: {e}")
            
        return results
    
    def scrape_36kr(self, keyword: str = "AI硬件", max_items: int = 10) -> List[Dict]:
        """
        抓取36氪上的AI硬件相关文章/项目
        
        Args:
            keyword: 搜索关键词
            max_items: 最大抓取数量
            
        Returns:
            文章列表
        """
        results = []
        
        try:
            # 36氪搜索API
            url = "https://www.36kr.com/api/search/articles"
            params = {
                'keyword': keyword,
                'page': 1,
                'per_page': max_items
            }
            
            response = self.session.get(url, params=params, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                articles = data.get('data', {}).get('items', [])
                
                for article in articles[:max_items]:
                    results.append({
                        'platform': '36氪',
                        'name': article.get('title', ''),
                        'description': article.get('summary', ''),
                        'url': f"https://www.36kr.com/p/{article.get('id', '')}",
                        'publish_time': article.get('published_at', ''),
                        'author': article.get('author', {}).get('name', ''),
                        'category': 'AI Hardware',
                        'scraped_at': datetime.now().isoformat()
                    })
                    
        except Exception as e:
            print(f"36氪抓取失败: {e}")
            
        return results
    
    def _parse_kickstarter_html(self, html: str) -> List[Dict]:
        """
        解析Kickstarter HTML（简化版）
        
        实际项目中可能需要使用BeautifulSoup或正则表达式
        更精确地提取项目信息
        """
        projects = []
        
        # 简单的正则匹配（示例）
        # 实际项目中建议使用BeautifulSoup
        pattern = r'data-project=\'([^\']+)\''
        matches = re.findall(pattern, html)
        
        for match in matches[:10]:
            try:
                project_data = json.loads(match)
                projects.append({
                    'name': project_data.get('name', ''),
                    'description': project_data.get('blurb', ''),
                    'url': project_data.get('urls', {}).get('web', {}).get('project', ''),
                    'goal': project_data.get('goal', {}).get('amount', ''),
                    'pledged': project_data.get('pledged', {}).get('amount', ''),
                    'backers': project_data.get('backers_count', ''),
                    'days_left': project_data.get('deadline', '')
                })
            except:
                continue
                
        return projects
    
    def scrape_all(self, keywords: List[str] = None) -> List[Dict]:
        """
        抓取所有平台的竞品信息
        
        Args:
            keywords: 搜索关键词列表
            
        Returns:
            所有平台的数据合并列表
        """
        if keywords is None:
            keywords = ["AI toy", "AI hardware", "smart toy", "robot toy"]
        
        all_results = []
        
        print("开始抓取竞品数据...")
        
        for keyword in keywords:
            print(f"\n搜索关键词: {keyword}")
            
            # Kickstarter
            print("  - 抓取Kickstarter...")
            ks_results = self.scrape_kickstarter(keyword)
            all_results.extend(ks_results)
            print(f"    获取 {len(ks_results)} 条")
            time.sleep(1)  # 礼貌性延迟
            
            # Indiegogo
            print("  - 抓取Indiegogo...")
            ig_results = self.scrape_indiegogo(keyword)
            all_results.extend(ig_results)
            print(f"    获取 {len(ig_results)} 条")
            time.sleep(1)
            
            # 36氪
            print("  - 抓取36氪...")
            kr_results = self.scrape_36kr(keyword)
            all_results.extend(kr_results)
            print(f"    获取 {len(kr_results)} 条")
            time.sleep(1)
        
        self.data = all_results
        print(f"\n✅ 共抓取 {len(all_results)} 条竞品数据")
        
        return all_results
    
    def save_to_json(self, filename: str = None) -> str:
        """保存数据为JSON文件"""
        if filename is None:
            filename = f"competitor_data_{datetime.now().strftime('%Y%m%d')}.json"
        
        filepath = f"data/{filename}"
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(self.data, f, ensure_ascii=False, indent=2)
        
        print(f"数据已保存到: {filepath}")
        return filepath
    
    def save_to_csv(self, filename: str = None) -> str:
        """保存数据为CSV文件"""
        import csv
        
        if filename is None:
            filename = f"competitor_data_{datetime.now().strftime('%Y%m%d')}.csv"
        
        filepath = f"data/{filename}"
        
        if not self.data:
            print("没有数据可保存")
            return ""
        
        # 获取所有字段
        fieldnames = set()
        for item in self.data:
            fieldnames.update(item.keys())
        fieldnames = sorted(list(fieldnames))
        
        with open(filepath, 'w', encoding='utf-8', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(self.data)
        
        print(f"数据已保存到: {filepath}")
        return filepath
    
    def load_from_data(self, data: List[Dict]):
        """从外部数据加载"""
        self.data = data
    
    def generate_report(self) -> Dict:
        """生成竞品分析报告"""
        if not self.data:
            return {'error': '没有数据可分析'}
        
        # 按平台统计
        platforms = {}
        categories = {}
        total_stars = 0
        
        for item in self.data:
            platform = item.get('platform', 'Unknown')
            platforms[platform] = platforms.get(platform, 0) + 1
            
            category = item.get('category', 'Unknown')
            categories[category] = categories.get(category, 0) + 1
            
            if 'stars' in item:
                try:
                    total_stars += int(item.get('stars', 0))
                except (ValueError, TypeError):
                    pass
        
        # 获取热门项目（按star排序）
        def get_stars(p):
            try:
                return int(p.get('stars', 0))
            except (ValueError, TypeError):
                return 0
        
        top_projects = sorted(
            [p for p in self.data if 'stars' in p],
            key=get_stars,
            reverse=True
        )[:5]
        
        return {
            'total_count': len(self.data),
            'platforms': platforms,
            'categories': categories,
            'total_stars': total_stars,
            'top_projects': [
                {
                    'name': p.get('name', ''),
                    'stars': p.get('stars', 0),
                    'url': p.get('url', '')
                }
                for p in top_projects
            ],
            'generated_at': datetime.now().isoformat()
        }
    
    def save_report(self, report: Dict, filename: str = None):
        """保存分析报告"""
        if filename is None:
            filename = f"data/competitor_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
        
        print(f"分析报告已保存: {filename}")
    
    def get_summary(self) -> Dict:
        """获取数据摘要"""
        if not self.data:
            return {}
        
        platforms = {}
        for item in self.data:
            platform = item.get('platform', 'Unknown')
            platforms[platform] = platforms.get(platform, 0) + 1
        
        return {
            'total_count': len(self.data),
            'platforms': platforms,
            'keywords_used': ["AI toy", "AI hardware", "smart toy", "robot toy"],
            'scraped_at': datetime.now().isoformat()
        }


# 使用示例
if __name__ == "__main__":
    scraper = CompetitorScraper()
    
    # 抓取所有平台
    results = scraper.scrape_all()
    
    # 保存数据
    scraper.save_to_json()
    scraper.save_to_csv()
    
    # 打印摘要
    summary = scraper.get_summary()
    print("\n数据摘要:")
    print(json.dumps(summary, ensure_ascii=False, indent=2))
