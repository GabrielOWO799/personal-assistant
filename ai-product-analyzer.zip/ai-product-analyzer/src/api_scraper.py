"""
API数据抓取模块
使用Product Hunt和GitHub API获取AI产品信息
"""

import requests
import json
from datetime import datetime
from typing import List, Dict, Optional


class APIScraper:
    """API数据抓取器"""
    
    def __init__(self, product_hunt_token: str = None, github_token: str = None):
        self.product_hunt_token = product_hunt_token
        self.github_token = github_token
        self.data = []
    
    def scrape_product_hunt(self, topic: str = "artificial-intelligence", max_items: int = 10) -> List[Dict]:
        """
        抓取Product Hunt上的AI产品
        
        Args:
            topic: 主题分类
            max_items: 最大抓取数量
            
        Returns:
            产品列表
        """
        results = []
        
        try:
            # Product Hunt GraphQL API
            url = "https://api.producthunt.com/v2/api/graphql"
            
            headers = {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.product_hunt_token}" if self.product_hunt_token else ""
            }
            
            # 查询最新产品
            query = """
            {
              posts(first: %d) {
                edges {
                  node {
                    id
                    name
                    tagline
                    description
                    url
                    votesCount
                    commentsCount
                    createdAt
                    topics {
                      edges {
                        node {
                          name
                        }
                      }
                    }
                    makers {
                      name
                    }
                  }
                }
              }
            }
            """ % max_items
            
            response = requests.post(
                url,
                headers=headers,
                json={"query": query},
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                posts = data.get('data', {}).get('posts', {}).get('edges', [])
                
                for post in posts:
                    node = post.get('node', {})
                    
                    # 过滤AI相关产品
                    topics = [t.get('node', {}).get('name', '') for t in node.get('topics', {}).get('edges', [])]
                    
                    if any(keyword in str(topics).lower() for keyword in ['ai', 'artificial', 'machine learning', 'chatbot']):
                        results.append({
                            'platform': 'Product Hunt',
                            'name': node.get('name', ''),
                            'tagline': node.get('tagline', ''),
                            'description': node.get('description', ''),
                            'url': node.get('url', ''),
                            'votes': node.get('votesCount', 0),
                            'comments': node.get('commentsCount', 0),
                            'created_at': node.get('createdAt', ''),
                            'topics': topics,
                            'makers': [m.get('name', '') for m in node.get('makers', [])],
                            'category': 'AI Product',
                            'scraped_at': datetime.now().isoformat()
                        })
                        
        except Exception as e:
            print(f"Product Hunt抓取失败: {e}")
            
        return results
    
    def scrape_github_trending(self, language: str = "python", max_items: int = 10) -> List[Dict]:
        """
        抓取GitHub Trending上的AI项目
        
        Args:
            language: 编程语言
            max_items: 最大抓取数量
            
        Returns:
            项目列表
        """
        results = []
        
        try:
            # GitHub Search API
            url = "https://api.github.com/search/repositories"
            
            headers = {
                "Accept": "application/vnd.github.v3+json"
            }
            
            if self.github_token:
                headers["Authorization"] = f"token {self.github_token}"
            
            # 搜索AI相关项目，按star排序
            params = {
                "q": "AI OR artificial-intelligence OR machine-learning OR llm OR chatbot language:python",
                "sort": "stars",
                "order": "desc",
                "per_page": max_items
            }
            
            response = requests.get(url, headers=headers, params=params, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                repos = data.get('items', [])
                
                for repo in repos:
                    results.append({
                        'platform': 'GitHub',
                        'name': repo.get('name', ''),
                        'full_name': repo.get('full_name', ''),
                        'description': repo.get('description', ''),
                        'url': repo.get('html_url', ''),
                        'stars': repo.get('stargazers_count', 0),
                        'forks': repo.get('forks_count', 0),
                        'language': repo.get('language', ''),
                        'created_at': repo.get('created_at', ''),
                        'updated_at': repo.get('updated_at', ''),
                        'topics': repo.get('topics', []),
                        'category': 'AI Open Source',
                        'scraped_at': datetime.now().isoformat()
                    })
                    
        except Exception as e:
            print(f"GitHub抓取失败: {e}")
            
        return results
    
    def scrape_github_daily_trending(self) -> List[Dict]:
        """
        抓取GitHub今日热门（使用第三方API）
        
        Returns:
            项目列表
        """
        results = []
        
        try:
            # 使用GitHub Trending RSS或第三方API
            # 这里使用一个开源的GitHub Trending API
            url = "https://github-trending-api.now.sh/repositories"
            
            params = {
                "language": "python",
                "since": "daily"
            }
            
            response = requests.get(url, params=params, timeout=10)
            
            if response.status_code == 200:
                repos = response.json()
                
                for repo in repos[:10]:
                    # 过滤AI相关项目
                    description = repo.get('description', '') or ''
                    if any(keyword in description.lower() for keyword in ['ai', 'artificial', 'machine learning', 'llm', 'chatbot', 'gpt']):
                        results.append({
                            'platform': 'GitHub Trending',
                            'name': repo.get('name', ''),
                            'author': repo.get('author', ''),
                            'description': description,
                            'url': repo.get('url', ''),
                            'stars': repo.get('stars', 0),
                            'forks': repo.get('forks', 0),
                            'language': repo.get('language', ''),
                            'current_period_stars': repo.get('currentPeriodStars', 0),
                            'category': 'AI Open Source',
                            'scraped_at': datetime.now().isoformat()
                        })
                        
        except Exception as e:
            print(f"GitHub Trending抓取失败: {e}")
            
        return results
    
    def scrape_all(self) -> List[Dict]:
        """
        抓取所有API数据源
        
        Returns:
            所有平台的数据合并列表
        """
        all_results = []
        
        print("开始抓取API数据...")
        
        # Product Hunt
        print("  - 抓取Product Hunt...")
        ph_results = self.scrape_product_hunt(max_items=20)
        all_results.extend(ph_results)
        print(f"    获取 {len(ph_results)} 条AI产品")
        
        # GitHub
        print("  - 抓取GitHub热门项目...")
        gh_results = self.scrape_github_trending(max_items=15)
        all_results.extend(gh_results)
        print(f"    获取 {len(gh_results)} 条开源项目")
        
        # GitHub Trending
        print("  - 抓取GitHub今日趋势...")
        gt_results = self.scrape_github_daily_trending()
        all_results.extend(gt_results)
        print(f"    获取 {len(gt_results)} 条趋势项目")
        
        self.data = all_results
        print(f"\n✅ 共抓取 {len(all_results)} 条数据")
        
        return all_results
    
    def save_to_json(self, filename: str = None) -> str:
        """保存数据为JSON文件"""
        if filename is None:
            filename = f"api_competitor_data_{datetime.now().strftime('%Y%m%d')}.json"
        
        filepath = f"data/{filename}"
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(self.data, f, ensure_ascii=False, indent=2)
        
        print(f"数据已保存到: {filepath}")
        return filepath
    
    def get_summary(self) -> Dict:
        """获取数据摘要"""
        if not self.data:
            return {}
        
        platforms = {}
        for item in self.data:
            platform = item.get('platform', 'Unknown')
            platforms[platform] = platforms.get(platform, 0) + 1
        
        # 统计GitHub stars
        total_stars = sum(item.get('stars', 0) for item in self.data if item.get('platform') == 'GitHub')
        
        return {
            'total_count': len(self.data),
            'platforms': platforms,
            'github_total_stars': total_stars,
            'scraped_at': datetime.now().isoformat()
        }


# 使用示例
if __name__ == "__main__":
    # 不需要token也能抓取GitHub公开数据
    scraper = APIScraper()
    
    # 抓取所有数据
    results = scraper.scrape_all()
    
    # 保存数据
    scraper.save_to_json()
    
    # 打印摘要
    summary = scraper.get_summary()
    print("\n数据摘要:")
    print(json.dumps(summary, ensure_ascii=False, indent=2))
