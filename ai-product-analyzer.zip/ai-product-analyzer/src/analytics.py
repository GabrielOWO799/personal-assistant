"""
数据分析与可视化模块
生成图表、趋势分析和深度洞察
"""

import json
import os
from datetime import datetime
from typing import List, Dict
from collections import Counter


class AnalyticsGenerator:
    """数据分析生成器"""
    
    def __init__(self, data: List[Dict] = None):
        self.data = data or []
        self.charts_dir = "data/charts"
        os.makedirs(self.charts_dir, exist_ok=True)
    
    def load_data(self, filepath: str):
        """从JSON文件加载数据"""
        with open(filepath, 'r', encoding='utf-8') as f:
            self.data = json.load(f)
    
    def analyze_topics(self) -> Dict:
        """分析技术标签热度"""
        all_topics = []
        for item in self.data:
            topics = item.get('topics', [])
            if isinstance(topics, list):
                all_topics.extend(topics)
        
        topic_counts = Counter(all_topics)
        return {
            'top_topics': topic_counts.most_common(20),
            'total_unique_topics': len(topic_counts)
        }
    
    def analyze_languages(self) -> Dict:
        """分析编程语言分布"""
        languages = []
        for item in self.data:
            lang = item.get('language')
            if lang:
                languages.append(lang)
        
        lang_counts = Counter(languages)
        return {
            'language_distribution': dict(lang_counts),
            'top_languages': lang_counts.most_common(10)
        }
    
    def analyze_platforms(self) -> Dict:
        """分析平台分布"""
        platforms = []
        for item in self.data:
            platform = item.get('platform', 'Unknown')
            platforms.append(platform)
        
        platform_counts = Counter(platforms)
        return {
            'platform_distribution': dict(platform_counts),
            'total_platforms': len(platform_counts)
        }
    
    def analyze_stars_distribution(self) -> Dict:
        """分析Star数分布"""
        stars = []
        for item in self.data:
            try:
                star = int(item.get('stars', 0))
                if star > 0:
                    stars.append(star)
            except:
                pass
        
        if not stars:
            return {}
        
        stars.sort(reverse=True)
        return {
            'total_stars': sum(stars),
            'average_stars': sum(stars) / len(stars),
            'median_stars': stars[len(stars) // 2] if stars else 0,
            'max_stars': max(stars),
            'min_stars': min(stars),
            'distribution': {
                '100k+': len([s for s in stars if s >= 100000]),
                '50k-100k': len([s for s in stars if 50000 <= s < 100000]),
                '10k-50k': len([s for s in stars if 10000 <= s < 50000]),
                '1k-10k': len([s for s in stars if 1000 <= s < 10000]),
                '<1k': len([s for s in stars if s < 1000])
            }
        }
    
    def analyze_trends(self) -> Dict:
        """分析创建时间趋势"""
        from datetime import datetime
        
        years = []
        for item in self.data:
            created = item.get('created_at', '')
            if created:
                try:
                    year = datetime.fromisoformat(created.replace('Z', '+00:00')).year
                    years.append(year)
                except:
                    pass
        
        year_counts = Counter(years)
        return {
            'yearly_distribution': dict(sorted(year_counts.items())),
            'most_active_year': year_counts.most_common(1)[0] if year_counts else None
        }
    
    def generate_full_analysis(self) -> Dict:
        """生成完整分析报告"""
        return {
            'summary': {
                'total_projects': len(self.data),
                'generated_at': datetime.now().isoformat()
            },
            'topics_analysis': self.analyze_topics(),
            'languages_analysis': self.analyze_languages(),
            'platforms_analysis': self.analyze_platforms(),
            'stars_analysis': self.analyze_stars_distribution(),
            'trends_analysis': self.analyze_trends()
        }
    
    def generate_markdown_report(self, analysis: Dict = None) -> str:
        """生成Markdown格式报告"""
        if analysis is None:
            analysis = self.generate_full_analysis()
        
        report = f"""# 🤖 AI竞品分析报告

> 生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

---

## 📊 数据概览

- **总项目数**: {analysis['summary']['total_projects']}
- **分析时间**: {analysis['summary']['generated_at'][:10]}

---

## 🏷️ 技术标签分析

**热门技术栈TOP 10**:
"""
        
        for topic, count in analysis['topics_analysis']['top_topics'][:10]:
            bar = '█' * min(count, 20)
            report += f"\n- `{topic}`: {count} {bar}"
        
        report += f"\n\n**独立标签总数**: {analysis['topics_analysis']['total_unique_topics']}\n"
        
        # 编程语言分布
        report += "\n---\n\n## 💻 编程语言分布\n\n"
        for lang, count in analysis['languages_analysis']['top_languages']:
            report += f"- **{lang}**: {count} 个项目\n"
        
        # Star分布
        stars = analysis['stars_analysis']
        if stars:
            report += f"""\n---\n
## ⭐ Star数分析

| 指标 | 数值 |
|------|------|
| 总Star数 | {stars['total_stars']:,} |
| 平均Star数 | {stars['average_stars']:,.0f} |
| 中位数 | {stars['median_stars']:,} |
| 最高Star数 | {stars['max_stars']:,} |
| 最低Star数 | {stars['min_stars']:,} |

**Star分布**:
"""
            for range_name, count in stars['distribution'].items():
                bar = '█' * count
                report += f"\n- {range_name}: {count} {bar}"
        
        # 平台分布
        report += "\n\n---\n\n## 🌐 平台分布\n\n"
        for platform, count in analysis['platforms_analysis']['platform_distribution'].items():
            report += f"- **{platform}**: {count} 个项目\n"
        
        # 时间趋势
        trends = analysis['trends_analysis']
        if trends['yearly_distribution']:
            report += "\n---\n\n## 📈 创建时间趋势\n\n"
            for year, count in sorted(trends['yearly_distribution'].items()):
                bar = '█' * min(count, 20)
                report += f"- **{year}**: {count} {bar}\n"
        
        report += "\n---\n\n*报告由AI竞品分析器自动生成*\n"
        
        return report
    
    def save_markdown_report(self, filename: str = None):
        """保存Markdown报告"""
        if filename is None:
            filename = f"{self.charts_dir}/../analytics_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md"
        
        report = self.generate_markdown_report()
        
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(report)
        
        print(f"分析报告已保存: {filename}")
        return filename
    
    def generate_text_summary(self) -> str:
        """生成文本摘要"""
        analysis = self.generate_full_analysis()
        
        summary = f"""
📊 AI竞品分析摘要
━━━━━━━━━━━━━━━━━━━━━━
总项目数: {analysis['summary']['total_projects']}
总Star数: {analysis['stars_analysis'].get('total_stars', 0):,}

🏷️ 热门标签: {', '.join([t[0] for t in analysis['topics_analysis']['top_topics'][:5]])}

💻 主要语言: {', '.join([l[0] for l in analysis['languages_analysis']['top_languages'][:3]])}

⭐ 平均Star: {analysis['stars_analysis'].get('average_stars', 0):,.0f}
━━━━━━━━━━━━━━━━━━━━━━
"""
        return summary


# 使用示例
if __name__ == "__main__":
    # 加载最新数据
    import glob
    
    data_files = glob.glob("data/combined_competitor_data_*.json")
    if data_files:
        latest_file = max(data_files)
        
        analytics = AnalyticsGenerator()
        analytics.load_data(latest_file)
        
        # 生成完整分析
        analysis = analytics.generate_full_analysis()
        
        # 保存Markdown报告
        analytics.save_markdown_report()
        
        # 打印摘要
        print(analytics.generate_text_summary())
    else:
        print("未找到数据文件")
