"""
需求优先级排序模块
基于竞品分析和用户画像，生成需求优先级建议
"""

import json
import os
from datetime import datetime
from typing import List, Dict, Tuple
from collections import Counter, defaultdict

from database import get_db
from user_profiler import UserProfiler


class PrioritySorter:
    """需求优先级排序器"""
    
    # 需求类型定义
    REQUIREMENT_TYPES = {
        'core_function': {'name': '核心功能', 'weight': 1.5},
        'user_experience': {'name': '用户体验', 'weight': 1.3},
        'technical': {'name': '技术优化', 'weight': 1.0},
        'business': {'name': '商业化', 'weight': 1.2},
        'security': {'name': '安全合规', 'weight': 1.4}
    }
    
    def __init__(self, db_path: str = "data/products.db"):
        self.db = get_db(db_path)
        self.requirements = []
        self.prioritized = []
    
    def generate_requirements(self) -> List[Dict]:
        """
        基于竞品数据生成需求列表
        """
        products = self.db.get_all_products(limit=200)
        
        if not products:
            print("⚠️ 数据库为空，无法生成需求")
            return []
        
        requirements = []
        
        # 1. 分析缺失的核心功能
        requirements.extend(self._analyze_core_functions(products))
        
        # 2. 分析用户体验需求
        requirements.extend(self._analyze_ux_needs(products))
        
        # 3. 分析技术需求
        requirements.extend(self._analyze_technical_needs(products))
        
        # 4. 分析商业化需求
        requirements.extend(self._analyze_business_needs(products))
        
        # 5. 分析安全合规需求
        requirements.extend(self._analyze_security_needs(products))
        
        self.requirements = requirements
        return requirements
    
    def _analyze_core_functions(self, products: List[Dict]) -> List[Dict]:
        """分析核心功能需求"""
        # 统计高频功能标签
        all_topics = []
        for p in products:
            topics = p.get('topics', [])
            if isinstance(topics, str):
                try:
                    topics = json.loads(topics)
                except:
                    continue
            all_topics.extend(topics)
        
        topic_counts = Counter(all_topics)
        
        # 基于高频标签推断核心功能需求
        core_requirements = []
        
        # AI Agent相关
        if any(t in ['agents', 'ai-agents', 'agentic-ai'] for t, _ in topic_counts.most_common(20)):
            core_requirements.append({
                'id': 'CORE-001',
                'type': 'core_function',
                'name': 'Agent工作流编排',
                'description': '支持多步骤AI Agent任务编排和执行',
                'evidence': f"{topic_counts.get('agents', 0) + topic_counts.get('ai-agents', 0)} 个竞品支持",
                'user_impact': '高',
                'implementation_cost': '高',
                'competitive_pressure': '高'
            })
        
        # RAG相关
        if any(t in ['rag', 'retrieval', 'knowledge-base'] for t, _ in topic_counts.most_common(20)):
            core_requirements.append({
                'id': 'CORE-002',
                'type': 'core_function',
                'name': 'RAG知识库集成',
                'description': '支持向量数据库和检索增强生成',
                'evidence': f"{topic_counts.get('rag', 0) + topic_counts.get('retrieval', 0)} 个竞品支持",
                'user_impact': '高',
                'implementation_cost': '中',
                'competitive_pressure': '高'
            })
        
        # 多模型支持
        core_requirements.append({
            'id': 'CORE-003',
            'type': 'core_function',
            'name': '多LLM提供商支持',
            'description': '支持OpenAI、Claude、Gemini、本地模型等多种LLM',
            'evidence': '主流竞品均支持多模型切换',
            'user_impact': '高',
            'implementation_cost': '中',
            'competitive_pressure': '高'
        })
        
        # 插件系统
        core_requirements.append({
            'id': 'CORE-004',
            'type': 'core_function',
            'name': '插件/扩展系统',
            'description': '支持第三方插件和自定义扩展',
            'evidence': 'LangChain、AutoGPT均有丰富插件生态',
            'user_impact': '中',
            'implementation_cost': '高',
            'competitive_pressure': '中'
        })
        
        return core_requirements
    
    def _analyze_ux_needs(self, products: List[Dict]) -> List[Dict]:
        """分析用户体验需求"""
        ux_requirements = []
        
        # 检查有多少产品有UI
        ui_products = [p for p in products if any(t in ['ui', 'gui', 'webui', 'interface'] for t in p.get('topics', []))]
        
        if len(ui_products) > len(products) * 0.3:
            ux_requirements.append({
                'id': 'UX-001',
                'type': 'user_experience',
                'name': '可视化界面',
                'description': '提供Web UI或桌面客户端，降低使用门槛',
                'evidence': f"{len(ui_products)} 个竞品提供可视化界面",
                'user_impact': '高',
                'implementation_cost': '中',
                'competitive_pressure': '高'
            })
        
        ux_requirements.extend([
            {
                'id': 'UX-002',
                'type': 'user_experience',
                'name': '一键部署方案',
                'description': '提供Docker、云服务等多种快速部署方式',
                'evidence': '用户反馈部署复杂是主要痛点',
                'user_impact': '高',
                'implementation_cost': '低',
                'competitive_pressure': '中'
            },
            {
                'id': 'UX-003',
                'type': 'user_experience',
                'name': '交互式教程',
                'description': '提供引导式教程和示例项目',
                'evidence': '新手用户普遍反映学习曲线陡峭',
                'user_impact': '中',
                'implementation_cost': '低',
                'competitive_pressure': '中'
            }
        ])
        
        return ux_requirements
    
    def _analyze_technical_needs(self, products: List[Dict]) -> List[Dict]:
        """分析技术需求"""
        tech_requirements = []
        
        # 分析主流技术栈
        languages = Counter([p.get('language') for p in products if p.get('language')])
        
        tech_requirements = [
            {
                'id': 'TECH-001',
                'type': 'technical',
                'name': 'Python SDK优先',
                'description': f'优先开发Python SDK（{languages.get("Python", 0)} 个竞品使用Python）',
                'evidence': f'Python占 {languages.get("Python", 0)/sum(languages.values())*100:.1f}%',
                'user_impact': '高',
                'implementation_cost': '低',
                'competitive_pressure': '高'
            },
            {
                'id': 'TECH-002',
                'type': 'technical',
                'name': 'API文档自动生成',
                'description': '提供OpenAPI/Swagger文档和交互式API测试',
                'evidence': '开发者普遍重视API文档质量',
                'user_impact': '中',
                'implementation_cost': '低',
                'competitive_pressure': '中'
            },
            {
                'id': 'TECH-003',
                'type': 'technical',
                'name': '性能监控和日志',
                'description': '内置性能指标监控和详细日志记录',
                'evidence': '企业用户需要可观测性',
                'user_impact': '中',
                'implementation_cost': '中',
                'competitive_pressure': '低'
            }
        ]
        
        return tech_requirements
    
    def _analyze_business_needs(self, products: List[Dict]) -> List[Dict]:
        """分析商业化需求"""
        return [
            {
                'id': 'BIZ-001',
                'type': 'business',
                'name': '灵活的定价策略',
                'description': '提供免费版、专业版、企业版等多 tier 定价',
                'evidence': 'SaaS产品主流商业模式',
                'user_impact': '高',
                'implementation_cost': '中',
                'competitive_pressure': '高'
            },
            {
                'id': 'BIZ-002',
                'type': 'business',
                'name': '私有化部署支持',
                'description': '支持企业内部部署，满足数据安全需求',
                'evidence': '企业用户的核心诉求',
                'user_impact': '高',
                'implementation_cost': '高',
                'competitive_pressure': '高'
            },
            {
                'id': 'BIZ-003',
                'type': 'business',
                'name': '企业级SLA',
                'description': '提供服务等级协议和技术支持',
                'evidence': '企业采购必要条件',
                'user_impact': '中',
                'implementation_cost': '中',
                'competitive_pressure': '中'
            }
        ]
    
    def _analyze_security_needs(self, products: List[Dict]) -> List[Dict]:
        """分析安全合规需求"""
        return [
            {
                'id': 'SEC-001',
                'type': 'security',
                'name': '数据加密存储',
                'description': '敏感数据加密存储和传输',
                'evidence': '企业合规基本要求',
                'user_impact': '高',
                'implementation_cost': '中',
                'competitive_pressure': '高'
            },
            {
                'id': 'SEC-002',
                'type': 'security',
                'name': '访问控制和权限管理',
                'description': '支持RBAC权限模型和SSO集成',
                'evidence': '多用户场景必需',
                'user_impact': '中',
                'implementation_cost': '中',
                'competitive_pressure': '中'
            }
        ]
    
    def calculate_priority_score(self, requirement: Dict) -> float:
        """
        计算需求优先级得分
        
        评分维度：
        - 用户影响 (1-5)
        - 竞争压力 (1-5)
        - 实现成本 (1-5，反向计分)
        - 类型权重
        """
        # 影响评分映射
        impact_scores = {'低': 1, '中': 3, '高': 5}
        cost_scores = {'低': 5, '中': 3, '高': 1}  # 成本低得分高
        
        user_impact = impact_scores.get(requirement['user_impact'], 3)
        competitive = impact_scores.get(requirement['competitive_pressure'], 3)
        cost = cost_scores.get(requirement['implementation_cost'], 3)
        
        # 类型权重
        type_weight = self.REQUIREMENT_TYPES.get(requirement['type'], {}).get('weight', 1.0)
        
        # 综合得分 (0-100)
        score = (user_impact * 0.4 + competitive * 0.3 + cost * 0.3) * type_weight * 10
        
        return round(score, 1)
    
    def prioritize(self) -> List[Dict]:
        """对需求进行优先级排序"""
        if not self.requirements:
            self.generate_requirements()
        
        # 计算每个需求的得分
        for req in self.requirements:
            req['score'] = self.calculate_priority_score(req)
        
        # 按得分排序
        sorted_reqs = sorted(self.requirements, key=lambda x: x['score'], reverse=True)
        
        # 添加优先级等级
        total = len(sorted_reqs)
        for i, req in enumerate(sorted_reqs):
            if i < total * 0.2:
                req['priority'] = 'P0'  # 最高优先级
                req['priority_desc'] = '必须做'
            elif i < total * 0.5:
                req['priority'] = 'P1'  # 高优先级
                req['priority_desc'] = '应该做'
            elif i < total * 0.8:
                req['priority'] = 'P2'  # 中优先级
                req['priority_desc'] = '可以做'
            else:
                req['priority'] = 'P3'  # 低优先级
                req['priority_desc'] = '暂缓'
        
        self.prioritized = sorted_reqs
        return sorted_reqs
    
    def generate_priority_report(self) -> str:
        """生成优先级报告（Markdown格式）"""
        if not self.prioritized:
            self.prioritize()
        
        report = f"""# 📋 需求优先级排序报告

> 生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
> 共分析 {len(self.prioritized)} 个需求

---

## 🎯 优先级分布

| 优先级 | 数量 | 说明 |
|--------|------|------|
| **P0 - 必须做** | {len([r for r in self.prioritized if r['priority'] == 'P0'])} | 核心功能，立即开发 |
| **P1 - 应该做** | {len([r for r in self.prioritized if r['priority'] == 'P1'])} | 重要需求，尽快安排 |
| **P2 - 可以做** | {len([r for r in self.prioritized if r['priority'] == 'P2'])} | 有资源时考虑 |
| **P3 - 暂缓** | {len([r for r in self.prioritized if r['priority'] == 'P3'])} | 低优先级，暂不处理 |

---

## 📊 TOP 10 高优先级需求

"""
        
        for i, req in enumerate(self.prioritized[:10], 1):
            type_info = self.REQUIREMENT_TYPES.get(req['type'], {})
            report += f"""### {i}. [{req['priority']}] {req['name']}

- **类型**: {type_info.get('name', req['type'])}
- **描述**: {req['description']}
- **评分**: {req['score']}/100
- **用户影响**: {req['user_impact']} | **竞争压力**: {req['competitive_pressure']} | **实现成本**: {req['implementation_cost']}
- **依据**: {req['evidence']}

---

"""
        
        # 按类型分组
        report += "## 📁 按类型分组\n\n"
        
        for type_key, type_info in self.REQUIREMENT_TYPES.items():
            type_reqs = [r for r in self.prioritized if r['type'] == type_key]
            if type_reqs:
                report += f"### {type_info['name']}\n\n"
                for req in type_reqs:
                    report += f"- **[{req['priority']}]** {req['name']} (评分: {req['score']})\n"
                report += "\n"
        
        # 开发建议
        report += """## 💡 开发建议

### 第一阶段（1-2个月）
专注P0需求，建立核心能力：
"""
        
        p0_reqs = [r for r in self.prioritized if r['priority'] == 'P0']
        for req in p0_reqs[:5]:
            report += f"- {req['name']}\n"
        
        report += """
### 第二阶段（3-4个月）
补充P1需求，提升竞争力：
"""
        
        p1_reqs = [r for r in self.prioritized if r['priority'] == 'P1']
        for req in p1_reqs[:5]:
            report += f"- {req['name']}\n"
        
        report += """
### 第三阶段（5-6个月）
完善P2需求，优化体验：
"""
        
        p2_reqs = [r for r in self.prioritized if r['priority'] == 'P2']
        for req in p2_reqs[:3]:
            report += f"- {req['name']}\n"
        
        report += "\n---\n\n*报告由AI竞品分析器自动生成*\n"
        
        return report
    
    def save_priority_report(self, filepath: str = None) -> str:
        """保存优先级报告"""
        if filepath is None:
            filepath = f"data/priority_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md"
        
        report = self.generate_priority_report()
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(report)
        
        print(f"✅ 优先级报告已保存: {filepath}")
        return filepath


# 便捷函数
def generate_priority_report(db_path: str = "data/products.db") -> str:
    """快速生成优先级报告"""
    sorter = PrioritySorter(db_path)
    sorter.prioritize()
    return sorter.save_priority_report()


# 测试
if __name__ == "__main__":
    sorter = PrioritySorter()
    requirements = sorter.generate_requirements()
    
    if requirements:
        print(f"\n📋 共生成 {len(requirements)} 个需求")
        
        prioritized = sorter.prioritize()
        
        print("\n🎯 优先级分布:")
        for p in ['P0', 'P1', 'P2', 'P3']:
            count = len([r for r in prioritized if r['priority'] == p])
            print(f"  {p}: {count} 个")
        
        print("\n📊 TOP 5 需求:")
        for i, req in enumerate(prioritized[:5], 1):
            print(f"{i}. [{req['priority']}] {req['name']} (评分: {req['score']})")
        
        # 保存报告
        report_path = sorter.save_priority_report()
        print(f"\n详细报告: {report_path}")
    else:
        print("⚠️ 请先在数据库中添加产品数据")
