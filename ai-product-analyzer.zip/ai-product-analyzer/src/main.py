"""
AI竞品分析器 - 主入口
整合API抓取、Selenium抓取和竞品分析功能
"""

import json
import sys
from datetime import datetime
from typing import List, Dict

from api_scraper import APIScraper
from selenium_scraper import SeleniumScraper
from competitor_scraper import CompetitorScraper
from analytics import AnalyticsGenerator
from exporter import DataExporter
from database import ProductDatabase
from comparator import ProductComparator


class AIProductAnalyzer:
    """AI竞品分析器主类"""
    
    def __init__(self, product_hunt_token: str = None, github_token: str = None, use_db: bool = True):
        self.product_hunt_token = product_hunt_token
        self.github_token = github_token
        self.use_db = use_db
        self.all_data = []
        self.api_scraper = None
        self.selenium_scraper = None
        self.competitor_analyzer = None
        self.db = ProductDatabase() if use_db else None
    
    def run_api_scraper(self) -> List[Dict]:
        """运行API抓取器"""
        print("\n" + "="*50)
        print("🚀 阶段1: API数据抓取")
        print("="*50)
        
        self.api_scraper = APIScraper(
            product_hunt_token=self.product_hunt_token,
            github_token=self.github_token
        )
        
        results = self.api_scraper.scrape_all()
        
        if results:
            self.api_scraper.save_to_json()
            summary = self.api_scraper.get_summary()
            print(f"\n📊 API抓取摘要:")
            print(json.dumps(summary, ensure_ascii=False, indent=2))
            
            # 保存到数据库
            if self.use_db:
                print("\n💾 保存到SQLite数据库...")
                db_result = self.db.insert_products(results)
                print(f"   数据库: 新增 {db_result['inserted']} 条, 更新 {db_result['updated']} 条")
        
        return results
    
    def run_selenium_scraper(self) -> List[Dict]:
        """运行Selenium抓取器"""
        print("\n" + "="*50)
        print("🌐 阶段2: Selenium浏览器抓取")
        print("="*50)
        
        self.selenium_scraper = SeleniumScraper(headless=True)
        
        if not self.selenium_scraper.driver:
            print("⚠️ Selenium初始化失败，跳过浏览器抓取")
            return []
        
        results = self.selenium_scraper.scrape_all()
        
        if results:
            self.selenium_scraper.save_to_json()
            
            # 保存到数据库
            if self.use_db:
                print("\n💾 保存到SQLite数据库...")
                db_result = self.db.insert_products(results)
                print(f"   数据库: 新增 {db_result['inserted']} 条, 更新 {db_result['updated']} 条")
        
        self.selenium_scraper.close()
        return results
    
    def run_competitor_analysis(self) -> Dict:
        """运行竞品分析"""
        print("\n" + "="*50)
        print("📈 阶段3: 竞品分析")
        print("="*50)
        
        self.competitor_analyzer = CompetitorScraper()
        
        # 加载已抓取的数据
        if self.all_data:
            self.competitor_analyzer.load_from_data(self.all_data)
        
        # 生成分析报告
        report = self.competitor_analyzer.generate_report()
        
        # 保存报告
        self.competitor_analyzer.save_report(report)
        
        return report
    
    def run_full_pipeline(self) -> Dict:
        """运行完整流程"""
        print("\n" + "="*60)
        print("🤖 AI竞品分析器 - 完整流程启动")
        print("="*60)
        print(f"开始时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        
        # 阶段1: API抓取
        api_results = self.run_api_scraper()
        self.all_data.extend(api_results)
        
        # 阶段2: Selenium抓取
        selenium_results = self.run_selenium_scraper()
        self.all_data.extend(selenium_results)
        
        print("\n" + "="*50)
        print(f"📦 数据汇总: 共 {len(self.all_data)} 条")
        print("="*50)
        
        # 保存到数据库
        if self.use_db and self.all_data:
            print("\n💾 保存到SQLite数据库...")
            db_result = self.db.insert_products(self.all_data)
            print(f"   数据库: 新增 {db_result['inserted']} 条, 更新 {db_result['updated']} 条")
        
        # 阶段3: 竞品分析
        if self.all_data:
            report = self.run_competitor_analysis()
        else:
            print("⚠️ 未获取到数据，跳过分析阶段")
            report = {}
        
        # 保存汇总数据
        data_file = self._save_combined_data()
        
        # 阶段4: 数据分析
        analysis = self.run_analytics(data_file)
        
        # 阶段5: 数据导出
        self.run_export(analysis)
        
        print("\n" + "="*60)
        print("✅ 完整流程完成!")
        print("="*60)
        print(f"结束时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print("\n生成的文件:")
        print(f"  📊 JSON数据: data/")
        print(f"  🗄️  SQLite数据库: data/products.db")
        print(f"  📄 分析报告: data/analytics_report_*.md")
        print(f"  📤 导出文件: data/exports/")
        print(f"  🌐 Web界面: python3 src/web_server.py")
        
        # 打印数据库统计
        if self.use_db:
            print("\n📈 数据库统计:")
            stats = self.db.get_statistics()
            print(f"   总产品数: {stats['total_products']}")
            print(f"   平台分布: {stats['platforms']}")
        
        return report
    
    def _save_combined_data(self):
        """保存汇总数据"""
        if not self.all_data:
            return
        
        filename = f"data/combined_competitor_data_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(self.all_data, f, ensure_ascii=False, indent=2)
        
        print(f"\n💾 汇总数据已保存: {filename}")
        return filename
    
    def run_analytics(self, data_file: str = None):
        """运行数据分析"""
        print("\n" + "="*50)
        print("📊 阶段4: 数据分析与可视化")
        print("="*50)
        
        analytics = AnalyticsGenerator()
        
        if data_file:
            analytics.load_data(data_file)
        elif self.all_data:
            analytics.data = self.all_data
        else:
            print("⚠️ 没有数据可分析")
            return None
        
        # 生成完整分析
        analysis = analytics.generate_full_analysis()
        
        # 保存Markdown报告
        report_file = analytics.save_markdown_report()
        
        # 打印摘要
        print(analytics.generate_text_summary())
        
        return analysis
    
    def run_export(self, analysis: Dict = None):
        """运行数据导出"""
        print("\n" + "="*50)
        print("📤 阶段5: 数据导出")
        print("="*50)
        
        exporter = DataExporter()
        
        if self.all_data:
            exporter.data = self.all_data
        else:
            print("⚠️ 没有数据可导出")
            return []
        
        # 导出所有格式
        exported = exporter.export_all(analysis)
        
        return exported
    
    def get_quick_summary(self) -> str:
        """获取快速摘要"""
        if not self.all_data:
            return "暂无数据"
        
        platforms = {}
        for item in self.all_data:
            platform = item.get('platform', 'Unknown')
            platforms[platform] = platforms.get(platform, 0) + 1
        
        summary = f"""
📊 数据汇总
━━━━━━━━━━━━━━━━━━━━━━
总数据量: {len(self.all_data)} 条

按平台分布:
"""
        for platform, count in platforms.items():
            summary += f"  • {platform}: {count} 条\n"
        
        return summary


def test_api_scraper():
    """测试API抓取器"""
    print("\n" + "="*50)
    print("🧪 测试: API抓取器")
    print("="*50)
    
    scraper = APIScraper()
    results = scraper.scrape_github_trending(max_items=5)
    
    if results:
        print(f"✅ 测试通过! 获取 {len(results)} 条数据")
        print(f"\n示例数据:")
        print(json.dumps(results[0], ensure_ascii=False, indent=2))
        return True
    else:
        print("❌ 测试失败: 未获取到数据")
        return False


def test_selenium_scraper():
    """测试Selenium抓取器"""
    print("\n" + "="*50)
    print("🧪 测试: Selenium抓取器")
    print("="*50)
    
    scraper = SeleniumScraper(headless=True)
    
    if not scraper.driver:
        print("⚠️ Chrome驱动未安装，跳过测试")
        return None
    
    results = scraper.scrape_github_trending(max_items=3)
    scraper.close()
    
    if results:
        print(f"✅ 测试通过! 获取 {len(results)} 条数据")
        return True
    else:
        print("⚠️ 测试完成但未获取到数据（可能网络问题）")
        return True


def run_tests():
    """运行所有测试"""
    print("\n" + "="*60)
    print("🧪 开始测试所有模块")
    print("="*60)
    
    results = {
        'api': test_api_scraper(),
        'selenium': test_selenium_scraper()
    }
    
    print("\n" + "="*60)
    print("📋 测试结果")
    print("="*60)
    for name, passed in results.items():
        status = "✅ 通过" if passed else "❌ 失败"
        if passed is None:
            status = "⏭️ 跳过"
        print(f"  {name}: {status}")
    
    return all(r for r in results.values() if r is not None)


def show_db_stats():
    """显示数据库统计"""
    print("\n" + "="*60)
    print("🗄️  数据库统计信息")
    print("="*60)
    
    db = ProductDatabase()
    stats = db.get_statistics()
    
    print(f"\n总产品数: {stats['total_products']}")
    print(f"总抓取次数: {stats['total_scrapes']}")
    print(f"最新抓取: {stats['latest_scrape']}")
    
    print("\n平台分布:")
    for platform, count in stats['platforms'].items():
        print(f"  • {platform}: {count} 条")
    
    print("\n分类分布:")
    for category, count in stats['categories'].items():
        print(f"  • {category}: {count} 条")
    
    # 抓取历史
    print("\n最近抓取记录:")
    history = db.get_scrape_history(limit=5)
    for log in history:
        print(f"  {log['scrape_time']}: {log['total_count']}条 (新增{log['new_count']}, 更新{log['updated_count']})")


def search_db(keyword: str):
    """搜索数据库"""
    print(f"\n🔍 搜索: '{keyword}'")
    print("="*60)
    
    db = ProductDatabase()
    results = db.search_products(keyword)
    
    print(f"找到 {len(results)} 条结果:\n")
    for item in results[:10]:  # 最多显示10条
        print(f"📌 {item['name']} ({item['platform']})")
        print(f"   {item.get('tagline', '') or item.get('description', '')[:60]}...")
        print(f"   ⭐ {item.get('stars', 0)} | 👍 {item.get('votes', 0)} | 🔗 {item.get('url', '')}")
        print()


def list_db_products():
    """列出数据库中的产品"""
    print("\n📋 数据库产品列表")
    print("="*60)
    
    comp = ProductComparator()
    products = comp.list_available_products(limit=50)
    
    print(f"共 {len(products)} 个产品:\n")
    for i, p in enumerate(products, 1):
        topics_str = ', '.join(p['topics'][:3]) if p['topics'] else 'N/A'
        print(f"{i}. {p['name']}")
        print(f"   平台: {p['platform']} | 语言: {p['language']} | ⭐{p['stars']}")
        print(f"   标签: {topics_str}")
        print()


def compare_products(product_names_str: str):
    """对比产品"""
    product_names = [name.strip() for name in product_names_str.split(',')]
    
    if len(product_names) < 2:
        print("❌ 请至少提供2个产品名称进行对比")
        print("示例: python src/main.py --compare 'Product A, Product B'")
        return
    
    print(f"\n🔍 对比分析: {', '.join(product_names)}")
    print("="*60)
    
    try:
        comp = ProductComparator()
        comp.compare_products(product_names)
        
        # 生成并保存报告
        report_path = comp.save_comparison_report()
        
        # 同时导出JSON数据
        json_path = comp.export_comparison_json()
        
        print(f"\n✅ 对比完成!")
        print(f"📄 Markdown报告: {report_path}")
        print(f"📊 JSON数据: {json_path}")
        
    except Exception as e:
        print(f"❌ 对比失败: {e}")
        print("\n提示: 使用 --list-products 查看可用产品名称")


def main():
    """主函数"""
    import argparse
    
    parser = argparse.ArgumentParser(description='AI竞品分析器')
    parser.add_argument('--test', action='store_true', help='运行测试模式')
    parser.add_argument('--api-only', action='store_true', help='仅运行API抓取')
    parser.add_argument('--selenium-only', action='store_true', help='仅运行Selenium抓取')
    parser.add_argument('--ph-token', type=str, help='Product Hunt API Token')
    parser.add_argument('--gh-token', type=str, help='GitHub API Token')
    parser.add_argument('--no-db', action='store_true', help='不使用数据库存储')
    parser.add_argument('--db-stats', action='store_true', help='显示数据库统计')
    parser.add_argument('--search', type=str, help='搜索数据库中的产品')
    parser.add_argument('--export-db', action='store_true', help='导出数据库到JSON')
    parser.add_argument('--compare', type=str, help='对比产品，用逗号分隔产品名')
    parser.add_argument('--list-products', action='store_true', help='列出数据库中的产品')
    
    args = parser.parse_args()
    
    if args.test:
        run_tests()
    elif args.db_stats:
        show_db_stats()
    elif args.search:
        search_db(args.search)
    elif args.export_db:
        db = ProductDatabase()
        db.export_to_json()
    elif args.list_products:
        list_db_products()
    elif args.compare:
        compare_products(args.compare)
    elif args.api_only:
        analyzer = AIProductAnalyzer(
            product_hunt_token=args.ph_token,
            github_token=args.gh_token,
            use_db=not args.no_db
        )
        analyzer.run_api_scraper()
    elif args.selenium_only:
        analyzer = AIProductAnalyzer(use_db=not args.no_db)
        analyzer.run_selenium_scraper()
    else:
        # 完整流程
        analyzer = AIProductAnalyzer(
            product_hunt_token=args.ph_token,
            github_token=args.gh_token,
            use_db=not args.no_db
        )
        analyzer.run_full_pipeline()


if __name__ == "__main__":
    main()
