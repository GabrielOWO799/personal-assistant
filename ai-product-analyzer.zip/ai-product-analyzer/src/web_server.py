"""
Web服务器模块
提供数据可视化和展示界面
"""

import json
import os
from datetime import datetime
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import parse_qs, urlparse
import glob


class DataHandler:
    """数据处理类"""
    
    @staticmethod
    def get_latest_data():
        """获取最新数据文件"""
        data_files = glob.glob("data/combined_competitor_data_*.json")
        if data_files:
            latest_file = max(data_files)
            with open(latest_file, 'r', encoding='utf-8') as f:
                return json.load(f), latest_file
        return [], None
    
    @staticmethod
    def get_analytics_report():
        """获取分析报告"""
        report_files = glob.glob("data/analytics_report_*.md")
        if report_files:
            latest_file = max(report_files)
            with open(latest_file, 'r', encoding='utf-8') as f:
                return f.read()
        return None


class WebHandler(BaseHTTPRequestHandler):
    """HTTP请求处理器"""
    
    def do_GET(self):
        """处理GET请求"""
        parsed_path = urlparse(self.path)
        path = parsed_path.path
        
        if path == '/' or path == '/index.html':
            self.serve_dashboard()
        elif path == '/data':
            self.serve_data_json()
        elif path == '/report':
            self.serve_report()
        elif path == '/api/stats':
            self.serve_stats_api()
        else:
            self.send_error(404)
    
    def serve_dashboard(self):
        """服务主页面"""
        data, data_file = DataHandler.get_latest_data()
        
        # 计算统计数据
        total_projects = len(data)
        total_stars = sum(int(p.get('stars', 0)) for p in data if 'stars' in p)
        platforms = {}
        languages = {}
        
        for item in data:
            platform = item.get('platform', 'Unknown')
            platforms[platform] = platforms.get(platform, 0) + 1
            
            lang = item.get('language', 'Unknown')
            if lang:
                languages[lang] = languages.get(lang, 0) + 1
        
        # 按star排序
        sorted_data = sorted(data, key=lambda x: int(x.get('stars', 0)) if 'stars' in x else 0, reverse=True)
        
        html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🤖 AI竞品分析器</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            color: #333;
        }}
        
        .container {{
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }}
        
        header {{
            text-align: center;
            color: white;
            padding: 40px 0;
        }}
        
        header h1 {{
            font-size: 2.5em;
            margin-bottom: 10px;
        }}
        
        header p {{
            opacity: 0.9;
            font-size: 1.1em;
        }}
        
        .stats-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }}
        
        .stat-card {{
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
            transition: transform 0.3s;
        }}
        
        .stat-card:hover {{
            transform: translateY(-5px);
        }}
        
        .stat-card h3 {{
            color: #666;
            font-size: 0.9em;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 10px;
        }}
        
        .stat-card .value {{
            font-size: 2.5em;
            font-weight: bold;
            color: #667eea;
        }}
        
        .content-grid {{
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 30px;
        }}
        
        @media (max-width: 900px) {{
            .content-grid {{
                grid-template-columns: 1fr;
            }}
        }}
        
        .panel {{
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
        }}
        
        .panel h2 {{
            margin-bottom: 20px;
            color: #333;
            border-bottom: 3px solid #667eea;
            padding-bottom: 10px;
        }}
        
        .project-list {{
            max-height: 500px;
            overflow-y: auto;
        }}
        
        .project-item {{
            padding: 15px;
            border-bottom: 1px solid #eee;
            transition: background 0.2s;
        }}
        
        .project-item:hover {{
            background: #f8f9fa;
        }}
        
        .project-item:last-child {{
            border-bottom: none;
        }}
        
        .project-name {{
            font-weight: bold;
            color: #667eea;
            font-size: 1.1em;
            margin-bottom: 5px;
        }}
        
        .project-meta {{
            color: #666;
            font-size: 0.9em;
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
        }}
        
        .project-meta span {{
            display: flex;
            align-items: center;
            gap: 5px;
        }}
        
        .badge {{
            background: #667eea;
            color: white;
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 0.8em;
        }}
        
        .chart-container {{
            margin-top: 20px;
        }}
        
        .bar-item {{
            display: flex;
            align-items: center;
            margin-bottom: 10px;
        }}
        
        .bar-label {{
            width: 100px;
            font-size: 0.9em;
        }}
        
        .bar {{
            flex: 1;
            height: 25px;
            background: #e9ecef;
            border-radius: 12px;
            overflow: hidden;
            margin: 0 10px;
        }}
        
        .bar-fill {{
            height: 100%;
            background: linear-gradient(90deg, #667eea, #764ba2);
            border-radius: 12px;
            transition: width 0.5s ease;
        }}
        
        .bar-value {{
            width: 50px;
            text-align: right;
            font-size: 0.9em;
            color: #666;
        }}
        
        footer {{
            text-align: center;
            color: white;
            padding: 20px;
            opacity: 0.8;
        }}
        
        .nav-links {{
            margin-top: 20px;
        }}
        
        .nav-links a {{
            color: white;
            text-decoration: none;
            margin: 0 15px;
            padding: 8px 16px;
            border: 2px solid white;
            border-radius: 20px;
            transition: all 0.3s;
        }}
        
        .nav-links a:hover {{
            background: white;
            color: #667eea;
        }}
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>🤖 AI竞品分析器</h1>
            <p>自动抓取和分析AI产品竞品数据</p>
            <div class="nav-links">
                <a href="/">📊 仪表板</a>
                <a href="/report">📄 分析报告</a>
                <a href="/data">📥 原始数据(JSON)</a>
            </div>
        </header>
        
        <div class="stats-grid">
            <div class="stat-card">
                <h3>总项目数</h3>
                <div class="value">{total_projects}</div>
            </div>
            <div class="stat-card">
                <h3>总Star数</h3>
                <div class="value">{total_stars:,}</div>
            </div>
            <div class="stat-card">
                <h3>数据来源</h3>
                <div class="value">{len(platforms)}</div>
            </div>
            <div class="stat-card">
                <h3>编程语言</h3>
                <div class="value">{len(languages)}</div>
            </div>
        </div>
        
        <div class="content-grid">
            <div class="panel">
                <h2>🔥 热门项目 TOP 10</h2>
                <div class="project-list">
"""
        
        # 添加项目列表
        for i, project in enumerate(sorted_data[:10], 1):
            name = project.get('name', 'Unknown')
            stars = project.get('stars', 0)
            language = project.get('language', 'N/A')
            platform = project.get('platform', 'Unknown')
            url = project.get('url', '#')
            
            html += f"""
                    <div class="project-item">
                        <div class="project-name">{i}. {name}</div>
                        <div class="project-meta">
                            <span>⭐ {stars:,}</span>
                            <span>💻 {language}</span>
                            <span class="badge">{platform}</span>
                        </div>
                    </div>
"""
        
        html += """
                </div>
            </div>
            
            <div class="panel">
                <h2>📊 平台分布</h2>
                <div class="chart-container">
"""
        
        # 添加平台分布图表
        max_count = max(platforms.values()) if platforms else 1
        for platform, count in sorted(platforms.items(), key=lambda x: x[1], reverse=True):
            percentage = (count / max_count) * 100
            html += f"""
                    <div class="bar-item">
                        <div class="bar-label">{platform}</div>
                        <div class="bar">
                            <div class="bar-fill" style="width: {percentage}%"></div>
                        </div>
                        <div class="bar-value">{count}</div>
                    </div>
"""
        
        html += """
                </div>
                
                <h2 style="margin-top: 30px;">💻 编程语言分布</h2>
                <div class="chart-container">
"""
        
        # 添加语言分布图表
        max_lang = max(languages.values()) if languages else 1
        for lang, count in sorted(languages.items(), key=lambda x: x[1], reverse=True):
            percentage = (count / max_lang) * 100
            html += f"""
                    <div class="bar-item">
                        <div class="bar-label">{lang}</div>
                        <div class="bar">
                            <div class="bar-fill" style="width: {percentage}%"></div>
                        </div>
                        <div class="bar-value">{count}</div>
                    </div>
"""
        
        html += f"""
                </div>
            </div>
        </div>
        
        <footer>
            <p>数据更新时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
            <p>AI竞品分析器 v1.0</p>
        </footer>
    </div>
</body>
</html>
"""
        
        self.send_response(200)
        self.send_header('Content-type', 'text/html; charset=utf-8')
        self.end_headers()
        self.wfile.write(html.encode('utf-8'))
    
    def serve_data_json(self):
        """服务JSON数据"""
        data, _ = DataHandler.get_latest_data()
        
        self.send_response(200)
        self.send_header('Content-type', 'application/json; charset=utf-8')
        self.end_headers()
        self.wfile.write(json.dumps(data, ensure_ascii=False, indent=2).encode('utf-8'))
    
    def serve_report(self):
        """服务分析报告"""
        report = DataHandler.get_analytics_report()
        
        if report:
            # 将Markdown转换为简单HTML
            html_content = report.replace('\n', '<br>')
            html_content = html_content.replace('# ', '<h1>').replace('<br>', '</h1><br>', 1)
            html_content = html_content.replace('## ', '<h2>')
            html_content = html_content.replace('### ', '<h3>')
            html_content = html_content.replace('**', '<strong>').replace('**', '</strong>')
            
            html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>📄 分析报告</title>
    <style>
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            max-width: 900px;
            margin: 0 auto;
            padding: 40px 20px;
            background: #f5f5f5;
        }}
        .container {{
            background: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }}
        h1 {{
            color: #667eea;
            border-bottom: 3px solid #667eea;
            padding-bottom: 10px;
        }}
        h2 {{
            color: #333;
            margin-top: 30px;
            border-bottom: 2px solid #eee;
            padding-bottom: 8px;
        }}
        .back-link {{
            display: inline-block;
            margin-bottom: 20px;
            color: #667eea;
            text-decoration: none;
        }}
        .back-link:hover {{
            text-decoration: underline;
        }}
    </style>
</head>
<body>
    <div class="container">
        <a href="/" class="back-link">← 返回仪表板</a>
        {html_content}
    </div>
</body>
</html>
"""
            
            self.send_response(200)
            self.send_header('Content-type', 'text/html; charset=utf-8')
            self.end_headers()
            self.wfile.write(html.encode('utf-8'))
        else:
            self.send_error(404, "报告未找到")
    
    def serve_stats_api(self):
        """服务统计API"""
        data, _ = DataHandler.get_latest_data()
        
        total_stars = sum(int(p.get('stars', 0)) for p in data if 'stars' in p)
        
        stats = {
            'total_projects': len(data),
            'total_stars': total_stars,
            'generated_at': datetime.now().isoformat()
        }
        
        self.send_response(200)
        self.send_header('Content-type', 'application/json; charset=utf-8')
        self.end_headers()
        self.wfile.write(json.dumps(stats, ensure_ascii=False).encode('utf-8'))
    
    def log_message(self, format, *args):
        """简化日志输出"""
        pass


def start_server(port=8080):
    """启动Web服务器"""
    server = HTTPServer(('0.0.0.0', port), WebHandler)
    print(f"\n🌐 Web服务器已启动!")
    print(f"   访问地址: http://localhost:{port}")
    print(f"   数据API: http://localhost:{port}/data")
    print(f"   分析报告: http://localhost:{port}/report")
    print(f"\n按 Ctrl+C 停止服务器\n")
    
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n\n服务器已停止")
        server.shutdown()


if __name__ == "__main__":
    import sys
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8080
    start_server(port)
