"""
数据可视化模块
生成带图表的HTML报告、词云、趋势图
"""

import json
import os
from datetime import datetime
from typing import List, Dict
from collections import Counter

from database import get_db


class VisualReportGenerator:
    """可视化报告生成器"""
    
    def __init__(self, db_path: str = "data/products.db"):
        self.db = get_db(db_path)
        self.output_dir = "data/reports"
        os.makedirs(self.output_dir, exist_ok=True)
    
    def generate_html_report(self, title: str = "AI竞品分析报告") -> str:
        """生成完整HTML报告"""
        products = self.db.get_all_products(limit=100)
        
        if not products:
            print("⚠️ 数据库为空，无法生成报告")
            return None
        
        # 准备数据
        stats = self._prepare_chart_data(products)
        
        # 生成HTML
        html = self._build_html(title, stats, products)
        
        # 保存文件
        filename = f"{self.output_dir}/visual_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html"
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(html)
        
        print(f"✅ HTML报告已生成: {filename}")
        return filename
    
    def _prepare_chart_data(self, products: List[Dict]) -> Dict:
        """准备图表数据"""
        # Stars分布
        stars_data = []
        for p in products[:20]:  # 前20个
            stars = p.get('stars', 0) or 0
            if stars > 0:
                stars_data.append({
                    'name': p['name'][:20],  # 截断长名称
                    'value': stars
                })
        
        # 语言分布
        languages = Counter([p.get('language', 'Unknown') for p in products if p.get('language')])
        lang_data = [{'name': k, 'value': v} for k, v in languages.most_common(10)]
        
        # 平台分布
        platforms = Counter([p.get('platform', 'Unknown') for p in products])
        platform_data = [{'name': k, 'value': v} for k, v in platforms.most_common()]
        
        # 技术标签词云数据
        all_topics = []
        for p in products:
            topics = p.get('topics', [])
            if isinstance(topics, str):
                try:
                    topics = json.loads(topics)
                except:
                    continue
            all_topics.extend(topics)
        topic_counts = Counter(all_topics)
        word_cloud_data = [{'name': k, 'value': v} for k, v in topic_counts.most_common(50)]
        
        return {
            'stars': stars_data,
            'languages': lang_data,
            'platforms': platform_data,
            'wordcloud': word_cloud_data
        }
    
    def _build_html(self, title: str, stats: Dict, products: List[Dict]) -> str:
        """构建HTML页面"""
        total = len(products)
        total_stars = sum(p.get('stars', 0) or 0 for p in products)
        
        # 准备Stars图表数据
        stars_names = [p['name'] for p in stats['stars']]
        stars_values = [p['wordcloud']]
        
        html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
    <script src="https://cdn.jsdelivr.net/npm/echarts@5.4.3/dist/echarts.min.js"></script>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; padding: 20px; }}
        .container {{ max-width: 1400px; margin: 0 auto; }}
        .header {{ background: white; padding: 30px; border-radius: 20px; margin-bottom: 20px; box-shadow: 0 10px 40px rgba(0,0,0,0.1); }}
        .header h1 {{ color: #333; font-size: 2.5em; margin-bottom: 10px; }}
        .header .meta {{ color: #666; font-size: 1.1em; }}
        .stats-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin-bottom: 30px; }}
        .stat-card {{ background: white; padding: 25px; border-radius: 15px; box-shadow: 0 5px 20px rgba(0,0,0,0.1); text-align: center; transition: transform 0.3s; }}
        .stat-card:hover {{ transform: translateY(-5px); }}
        .stat-number {{ font-size: 2.5em; font-weight: bold; color: #667eea; }}
        .stat-label {{ color: #666; margin-top: 5px; }}
        .chart-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(600px, 1fr)); gap: 20px; margin-bottom: 30px; }}
        .chart-container {{ background: white; padding: 20px; border-radius: 15px; box-shadow: 0 5px 20px rgba(0,0,0,0.1); }}
        .chart-title {{ font-size: 1.3em; color: #333; margin-bottom: 15px; font-weight: 600; }}
        .chart {{ width: 100%; height: 400px; }}
        .product-list {{ background: white; padding: 30px; border-radius: 15px; box-shadow: 0 5px 20px rgba(0,0,0,0.1); }}
        .product-item {{ padding: 15px 0; border-bottom: 1px solid #eee; display: flex; justify-content: space-between; align-items: center; }}
        .product-name {{ font-weight: 600; color: #333; }}
        .product-desc {{ color: #666; font-size: 0.9em; }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🤖 {title}</h1>
            <div class="meta">生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | 共 {total} 个产品 | 总Stars: {total_stars:,}</div>
        </div>
        
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-number">{total}</div>
                <div class="stat-label">产品总数</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">{total_stars:,}</div>
                <div class="stat-label">总Stars</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">{len([p for p in products if p.get('language') == 'Python'])}</div>
                <div class="stat-label">Python项目</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">{len(set([p.get('platform') for p in products]))}</div>
                <div class="stat-label">来源平台</div>
            </div>
        </div>
        
        <div class="chart-grid">
            <div class="chart-container">
                <div class="chart-title">📊Stars排名 1080 }}</div>
                <div id="starsChart" class="chart"></div>
            </div>
            <div class="chart-container">
                <div class="chart-title">💻 编程语言分布</div>
                <div id="langChart" class="chart"></div>
            </div>
            <div class="chart-container">
                <div class="chart-title">🌐 平台分布</div>
                <div id="platformChart" class="chart"></div>
            </div>
            <div class="chart-container">
                <div class="chart-title">🏷️ 技术标签词云</div>
                <div id="wordcloudChart" class="chart"></div>
            </div>
        </div>
        
        <div class="product-list">
            <h2 style="margin-bottom: 20px; color: #333;">📋 产品列表TOP 50</h2>
            {self._generate_product_list(products) }
        </div>
    </div>
    
    <script>
        // Stars柱状图
        var starsChart = echarts.init(document.getElementById('starsChart'));
        starsChart.setOption({
            tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
            grid: { left: '3%', right: '4%', bottom: '3%', containLabel: true },
            xAxis: { type: 'category', data: {json.dumps([p['name'] for p in stats['stars']])}, axisLabel: { rotate: 45 } },
            yAxis: { type: 'value' },
            series: [{{ data: {json.dumps([p['value'] for p in stats['stars']}), type: 'bar', itemStyle: {{ color: '#667eea' }} }]
        });
        
        // 词云
        var wordcloudChart = echarts.init(document.getElementById('wordcloudChart'));
        wordcloudChart.setOption({
            series: [{
                type: 'wordCloud',
                shape: 'circle',
                data: {json.dumps(stats['wordcloud']) },
                textStyle: { fontFamily: 'sans-serif', fontWeight: 'bold' },
                emphasis: { focus: 'self' }
            }]
        });
        
        // 语言饼图
        var langChart = echarts.init(document.getElementById('langChart'));
        langChart.setOption({
            tooltip: { trigger: 'item' },
            series: [{
                type: 'pie',
                radius: '50%',
                data: {json.dumps(stats['languages']) },
                emphasis: { itemStyle: { shadowBlur: 10, shadowOffsetX: 0, shadowColor: 'rgba(0, 0, 0, 0.5)' } }
            }]
        });
        
        // 平台饼图
        var platformChart = echarts.init(document.getElementById('platformChart'));
        platformChart.setOption({
            tooltip: { trigger: 'item' },
            E: [{
                type: 'pie',
                radius: ['40%', '70%'],
                avoidLabelOverlap: false,
                itemStyle: { borderRadius: 10, borderColor: '#fff', borderWidth: 2 },
                label: { show: false, position: 'center' },
                emphasis: { label: { show: true, fontSize: 20, fontWeight: 'bold' } },
                data: {json.dumps(stats['platforms']) }
            }]
        });
        
        // 响应式
        window.addEventListener('resize', function() {
            starsChart.resize();
            wordcloudChart.resize();
            langChart.resize();
            platformChart.resize();
        });
    </script>
</body>
</html>"""
        
        return html
    
    def _generate_product_list(self, products: List[Dict]) -> str:
        """生成产品列表HTML"""
        items = []
        for i, p in enumerate(products[:50], 1):
            stars = p.get('stars', 0) or 0
            items.append(f"""
                <div class="product-item">
                    <div>
                        <div class="product-name">{i}. {p['name']}</div>
                        <div class="product-desc">{p.get('tagline', '')[:60] or p.get('description', '')[:60]}</div>
                    </div>
                    <div style="text-align: right;">
                        <div style="font-weight: bold; color: #667eea;">⭐ {stars:,}</div>
                        <div style="font-size: 0.9em; color: #666;">{p.get('language', 'N/A')}</div>
                    </div>
                </div>
            """)
        return '\n'.join(items)


# 便捷函数
def generate_visual_report(db_path: str = "data/products.db") -> str:
    """快速生成可视化报告"""
    gen = VisualReportGenerator(db_path)
    return gen.generate_html_report()


# 测试
if __name__ == "__main__":
    gen = VisualReportGenerator()
    report = gen.generate_html_report()
    if report:
        print(f"\n✅ 报告生成完成: {report}")
        print(f"请用浏览器打开: file://{os.path.abspath(report)}")
