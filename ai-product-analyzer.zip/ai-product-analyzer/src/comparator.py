"""
竞品对比分析模块
支持多产品横向对比、优劣势分析和可视化报告生成
"""

import json
import os
from datetime import datetime
from typing import List, Dict, Optional, Tuple
from collections import Counter
import sqlite3

from database import ProductDatabase, get_db


class ProductComparator:
    """产品对比分析器"""
    
    def __init__(self, db_path: str = "data/products.db"):
        self.db = get_db(db_path)
        self.comparison_results = {}
    
    def list_available_products(self, platform: str = None, category: str = None, limit: int = 50) -> List[Dict]:
        """
        列出可用于对比的产品列表
        
        Args:
            platform: 筛选特定平台
            category: 筛选特定分类
            limit: 返回数量限制
            
        Returns:
            产品列表（包含基本信息）
        """
        with self.db._get_connection() as conn:
            cursor = conn.cursor()
            
            query = '''
                SELECT name, platform, category, tagline, stars, votes, 
                       language, topics, scraped_at
                FROM products 
                WHERE 1=1
            '''
            params = []
            
            if platform:
                query += ' AND platform = ?'
                params.append(platform)
            
            if category:
                query += ' AND category = ?'
                params.append(category)
            
            query += ' ORDER BY stars DESC LIMIT ?'
            params.append(limit)
            
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            products = []
            for row in rows:
                topics = []
                if row['topics']:
                    try:
                        topics = json.loads(row['topics'])
                    except:
                        pass
                
                products.append({
                    'name': row['name'],
                    'platform': row['platform'],
                    'category': row['category'],
                    'tagline': row['tagline'],
                    'stars': row['stars'] or 0,
                    'votes': row['votes'] or 0,
                    'language': row['language'],
                    'topics': topics[:5],  # 只显示前5个标签
                    'scraped_at': row['scraped_at']
                })
            
            return products
    
    def get_product_details(self, name: str) -> Optional[Dict]:
        """获取产品详细信息"""
        return self.db.get_product_by_name(name)
    
    def compare_products(self, product_names: List[str]) -> Dict:
        """
        对比多个产品
        
        Args:
            product_names: 产品名称列表（2-5个）
            
        Returns:
            对比分析结果
        """
        if len(product_names) < 2:
            raise ValueError("至少需要选择2个产品进行对比")
        
        if len(product_names) > 5:
            raise ValueError("最多支持5个产品同时对比")
        
        # 获取产品详情
        products = []
        for name in product_names:
            product = self.get_product_details(name)
            if product:
                products.append(product)
            else:
                print(f"⚠️ 未找到产品: {name}")
        
        if len(products) < 2:
            raise ValueError("至少需要找到2个有效产品才能对比")
        
        # 执行各项对比分析
        comparison = {
            'products': products,
            'basic_comparison': self._compare_basic_info(products),
            'metrics_comparison': self._compare_metrics(products),
            'tech_stack_comparison': self._compare_tech_stack(products),
            'feature_comparison': self._compare_features(products),
            'swot_analysis': self._generate_swot_analysis(products),
            'generated_at': datetime.now().isoformat()
        }
        
        self.comparison_results = comparison
        return comparison
    
    def _compare_basic_info(self, products: List[Dict]) -> Dict:
        """对比基本信息"""
        return {
            'names': [p['name'] for p in products],
            'platforms': [p.get('platform', 'Unknown') for p in products],
            'categories': [p.get('category', 'Unknown') for p in products],
            'languages': [p.get('language', 'N/A') for p in products],
            'created_dates': [p.get('created_at', 'N/A') for p in products],
            'urls': [p.get('url', '') for p in products]
        }
    
    def _compare_metrics(self, products: List[Dict]) -> Dict:
        """对比核心指标"""
        metrics = []
        
        for p in products:
            metrics.append({
                'name': p['name'],
                'stars': p.get('stars', 0) or 0,
                'forks': p.get('forks', 0) or 0,
                'votes': p.get('votes', 0) or 0,
                'comments': p.get('comments', 0) or 0
            })
        
        # 计算排名
        stars_ranking = sorted(metrics, key=lambda x: x['stars'], reverse=True)
        forks_ranking = sorted(metrics, key=lambda x: x['forks'], reverse=True)
        
        return {
            'metrics': metrics,
            'stars_ranking': [{'name': m['name'], 'stars': m['stars']} for m in stars_ranking],
            'forks_ranking': [{'name': m['name'], 'forks': m['forks']} for m in forks_ranking],
            'total_stars': sum(m['stars'] for m in metrics),
            'total_forks': sum(m['forks'] for m in metrics)
        }
    
    def _compare_tech_stack(self, products: List[Dict]) -> Dict:
        """对比技术栈"""
        all_topics = set()
        product_topics = {}
        
        for p in products:
            topics = p.get('topics', [])
            if isinstance(topics, str):
                try:
                    topics = json.loads(topics)
                except:
                    topics = []
            product_topics[p['name']] = set(topics)
            all_topics.update(topics)
        
        # 找出共同技术栈
        common_topics = set.intersection(*product_topics.values()) if product_topics else set()
        
        # 找出每个产品独有的技术栈
        unique_topics = {}
        for name, topics in product_topics.items():
            others = set.union(*[t for n, t in product_topics.items() if n != name]) if len(product_topics) > 1 else set()
            unique_topics[name] = topics - others
        
        return {
            'all_topics': sorted(list(all_topics)),
            'common_topics': sorted(list(common_topics)),
            'unique_topics': {k: sorted(list(v)) for k, v in unique_topics.items()},
            'topic_counts': {name: len(topics) for name, topics in product_topics.items()}
        }
    
    def _compare_features(self, products: List[Dict]) -> Dict:
        """对比功能特性（基于描述和标签）"""
        features = []
        
        for p in products:
            desc = p.get('description', '') or p.get('tagline', '')
            
            # 提取关键特性（基于关键词匹配）
            detected_features = self._extract_features_from_text(desc)
            
            features.append({
                'name': p['name'],
                'description': desc[:200] + '...' if len(desc) > 200 else desc,
                'detected_features': detected_features
            })
        
        return {'features': features}
    
    def _extract_features_from_text(self, text: str) -> List[str]:
        """从文本中提取功能特性关键词"""
        if not text:
            return []
        
        text_lower = text.lower()
        
        feature_keywords = {
            'AI/ML': ['ai', 'machine learning', 'ml', 'deep learning', 'neural', 'model'],
            'LLM': ['llm', 'large language model', 'gpt', 'claude', 'openai'],
            'Agent': ['agent', 'autonomous', 'workflow', 'automation'],
            'RAG': ['rag', 'retrieval', 'knowledge base', 'vector'],
            'Chat': ['chat', 'conversation', 'dialogue', 'chatbot'],
            'API': ['api', 'sdk', 'integration', 'plugin'],
            'Open Source': ['open source', 'github', 'mit', 'apache'],
            'Self-hosted': ['self-hosted', 'local', 'on-premise', 'private'],
            'Cloud': ['cloud', 'saas', 'hosted', 'service'],
            'Multi-modal': ['multimodal', 'vision', 'image', 'audio', 'voice']
        }
        
        detected = []
        for feature, keywords in feature_keywords.items():
            if any(kw in text_lower for kw in keywords):
                detected.append(feature)
        
        return detected
    
    def _generate_swot_analysis(self, products: List[Dict]) -> Dict:
        """生成SWOT分析（优劣势分析）"""
        swot = {}
        
        for p in products:
            name = p['name']
            stars = p.get('stars', 0) or 0
            forks = p.get('forks', 0) or 0
            topics = p.get('topics', [])
            if isinstance(topics, str):
                try:
                    topics = json.loads(topics)
                except:
                    topics = []
            
            strengths = []
            weaknesses = []
            
            # 基于指标判断优劣势
            if stars > 10000:
                strengths.append(f"高社区认可度 ({stars:,} stars)")
            elif stars < 1000:
                weaknesses.append("社区关注度较低")
            
            if forks > 1000:
                strengths.append(f"活跃的开发者社区 ({forks:,} forks)")
            
            if len(topics) > 5:
                strengths.append(f"丰富的技术生态 ({len(topics)} 个技术标签)")
            
            if p.get('language') in ['Python', 'TypeScript', 'JavaScript']:
                strengths.append(f"使用主流语言 {p['language']}")
            
            if not strengths:
                strengths.append("新兴项目，有成长潜力")
            
            if not weaknesses:
                weaknesses.append("需要更多市场验证")
            
            swot[name] = {
                'strengths': strengths,
                'weaknesses': weaknesses,
                'opportunities': ["AI市场快速增长", "可扩展更多功能模块"],
                'threats': ["竞品激烈", "技术迭代快"]
            }
        
        return swot
    
    def generate_comparison_table(self, comparison: Dict = None) -> str:
        """生成对比表格（Markdown格式）"""
        if comparison is None:
            comparison = self.comparison_results
        
        if not comparison:
            return "暂无对比数据"
        
        products = comparison['products']
        metrics = comparison['metrics_comparison']['metrics']
        tech = comparison['tech_stack_comparison']
        
        # 构建表格
        table = "# 🔍 竞品对比分析报告\n\n"
        table += f"> 生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
        
        # 基础信息对比表
        table += "## 📋 基础信息对比\n\n"
        table += "| 产品 | 平台 | 语言 | Stars | Forks | 技术标签数 |\n"
        table += "|------|------|------|-------|-------|-----------|\n"
        
        for p in products:
            m = next((x for x in metrics if x['name'] == p['name']), {})
            topic_count = tech['topic_counts'].get(p['name'], 0)
            table += f"| **{p['name']}** | {p.get('platform', 'N/A')} | {p.get('language', 'N/A')} | {m.get('stars', 0):,} | {m.get('forks', 0):,} | {topic_count} |\n"
        
        # 指标排名
        table += "\n## 🏆 指标排名\n\n"
        table += "### Stars排名\n"
        for i, item in enumerate(comparison['metrics_comparison']['stars_ranking'], 1):
            bar = "⭐" * min(i, 5)
            table += f"{i}. **{item['name']}**: {item['stars']:,} {bar}\n"
        
        # 技术栈对比
        table += "\n## 🛠️ 技术栈对比\n\n"
        
        if tech['common_topics']:
            table += f"**共同技术栈**: {', '.join(tech['common_topics'])}\n\n"
        
        table += "**各产品技术特点**:\n\n"
        for name, unique in tech['unique_topics'].items():
            if unique:
                table += f"- **{name}** 独有: {', '.join(unique[:8])}\n"
        
        # SWOT分析
        table += "\n## 📊 SWOT分析\n\n"
        for name, analysis in comparison['swot_analysis'].items():
            table += f"### {name}\n\n"
            table += f"**✅ 优势**: {', '.join(analysis['strengths'])}\n\n"
            table += f"**⚠️ 劣势**: {', '.join(analysis['weaknesses'])}\n\n"
        
        # 结论建议
        table += "\n## 💡 结论与建议\n\n"
        table += self._generate_recommendations(comparison)
        
        return table
    
    def _generate_recommendations(self, comparison: Dict) -> str:
        """生成推荐建议"""
        products = comparison['products']
        metrics = comparison['metrics_comparison']
        
        recommendations = []
        
        # 找出领先者
        if metrics['stars_ranking']:
            leader = metrics['stars_ranking'][0]
            recommendations.append(f"1. **社区认可度最高**: {leader['name']} ({leader['stars']:,} stars)，可作为主要参考对象")
        
        # 技术栈建议
        tech = comparison['tech_stack_comparison']
        if tech['common_topics']:
            recommendations.append(f"2. **核心技术栈**: {', '.join(tech['common_topics'][:5])} 是竞品共同采用的技术，建议优先考虑")
        
        # 差异化建议
        if len(products) == 2:
            p1, p2 = products[0], products[1]
            s1, s2 = p1.get('stars', 0) or 0, p2.get('stars', 0) or 0
            if abs(s1 - s2) > max(s1, s2) * 0.3:
                stronger = p1 if s1 > s2 else p2
                recommendations.append(f"3. **差异化机会**: {stronger['name']} 已建立明显优势，建议寻找细分市场或差异化功能")
            else:
                recommendations.append(f"3. **竞争态势**: 两者实力接近，市场仍有争夺空间")
        
        return '\n'.join(recommendations) if recommendations else "建议进一步分析具体功能差异"
    
    def save_comparison_report(self, filepath: str = None) -> str:
        """保存对比报告到文件"""
        if filepath is None:
            filepath = f"data/comparison_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md"
        
        report = self.generate_comparison_table()
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(report)
        
        print(f"✅ 对比报告已保存: {filepath}")
        return filepath
    
    def export_comparison_json(self, filepath: str = None) -> str:
        """导出对比结果为JSON"""
        if filepath is None:
            filepath = f"data/comparison_data_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(self.comparison_results, f, ensure_ascii=False, indent=2)
        
        print(f"✅ 对比数据已导出: {filepath}")
        return filepath


# 便捷函数
def compare(product_names: List[str], db_path: str = "data/products.db") -> ProductComparator:
    """快速对比函数"""
    comp = ProductComparator(db_path)
    comp.compare_products(product_names)
    return comp


# 测试代码
if __name__ == "__main__":
    # 初始化对比器
    comp = ProductComparator()
    
    # 列出可用产品
    print("📋 可用产品列表（前10个）:")
    products = comp.list_available_products(limit=10)
    for i, p in enumerate(products, 1):
        print(f"{i}. {p['name']} ({p['platform']}) - ⭐{p['stars']}")
    
    if len(products) >= 2:
        # 选择前2个产品进行对比测试
        test_names = [products[0]['name'], products[1]['name']]
        print(f"\n🔍 对比测试: {test_names[0]} vs {test_names[1]}")
        
        try:
            result = comp.compare_products(test_names)
            
            # 生成并保存报告
            comp.save_comparison_report()
            
            # 导出JSON
            comp.export_comparison_json()
            
            print("\n✅ 对比分析完成!")
            
        except Exception as e:
            print(f"❌ 对比失败: {e}")
    else:
        print("\n⚠️ 数据库中产品数量不足，无法进行对比测试")
        print("请先运行抓取任务添加一些产品数据")
