"""
用户画像生成模块
基于竞品数据生成目标用户画像
"""

import json
import os
from datetime import datetime
from typing import List, Dict, Optional
from collections import Counter, defaultdict

from database import get_db


class UserProfiler:
    """用户画像生成器"""
    
    def __init__(self, db_path: str = "data/products.db"):
        self.db = get_db(db_path)
        self.personas = {}
    
    def generate_personas(self) -> Dict:
        """
        生成用户画像
        
        基于竞品数据推断目标用户群体特征
        """
        products = self.db.get_all_products(limit=200)
        
        if not products:
            print("⚠️ 数据库为空，无法生成用户画像")
            return {}
        
        personas = {
            'technical_users': self._analyze_technical_users(products),
            'business_users': self._analyze_business_users(products),
            'casual_users': self._analyze_casual_users(products),
            'enterprise_users': self._analyze_enterprise_users(products),
            'generated_at': datetime.now().isoformat()
        }
        
        self.personas = personas
        return personas
    
    def _analyze_technical_users(self, products: List[Dict]) -> Dict:
        """分析技术用户画像"""
        # 筛选技术导向的产品（高stars、有特定技术标签）
        tech_products = [p for p in products if p.get('stars', 0) > 1000]
        
        # 技术栈偏好
        all_topics = []
        languages = []
        for p in tech_products:
            topics = p.get('topics', [])
            if isinstance(topics, str):
                try:
                    topics = json.loads(topics)
                except:
                    continue
            all_topics.extend(topics)
            if p.get('language'):
                languages.append(p['language'])
        
        topic_counts = Counter(all_topics)
        lang_counts = Counter(languages)
        
        # 推断技术用户特征
        return {
            'name': '技术开发者',
            'description': '关注技术实现、开源项目、代码质量的开发者群体',
            'size': '大型',
            'characteristics': [
                f"偏好语言: {', '.join([l[0] for l in lang_counts.most_common(3)])}",
                f"关注技术: {', '.join([t[0] for t in topic_counts.most_common(5)])}",
                '重视开源社区活跃度',
                '关注技术文档和示例代码',
                '愿意为优质工具付费或贡献代码'
            ],
            'pain_points': [
                '现有工具集成复杂',
                '文档不完善',
                'API不稳定',
                '缺乏企业级支持'
            ],
            'needs': [
                '清晰的API文档',
                '丰富的代码示例',
                '活跃的社区支持',
                '稳定的版本迭代'
            ],
            'tech_preferences': topic_counts.most_common(10),
            'language_preferences': lang_counts.most_common(5),
            'sample_products': [p['name'] for p in tech_products[:5]]
        }
    
    def _analyze_business_users(self, products: List[Dict]) -> Dict:
        """分析商业用户画像"""
        # 筛选商业导向的产品（有enterprise标签、描述含商业关键词）
        business_keywords = ['enterprise', 'business', 'commercial', 'saas', 'platform']
        business_products = []
        
        for p in products:
            desc = (p.get('description', '') + ' ' + p.get('tagline', '')).lower()
            topics = p.get('topics', [])
            if isinstance(topics, str):
                try:
                    topics = json.loads(topics)
                except:
                    topics = []
            
            if any(kw in desc for kw in business_keywords) or 'enterprise' in topics:
                business_products.append(p)
        
        return {
            'name': '商业用户',
            'description': '关注商业价值、ROI、企业级功能的企业决策者',
            'size': '中型',
            'characteristics': [
                '关注投资回报率',
                '重视数据安全和合规',
                '需要企业级支持',
                '决策流程较长'
            ],
            'pain_points': [
                '成本难以控制',
                '数据隐私担忧',
                '集成现有系统困难',
                '缺乏定制化服务'
            ],
            'needs': [
                '透明的定价策略',
                '企业级SLA保障',
                '私有化部署选项',
                '专业的技术支持'
            ],
            'sample_products': [p['name'] for p in business_products[:5]] if business_products else ['LangChain', 'AutoGPT']
        }
    
    def _analyze_casual_users(self, products: List[Dict]) -> Dict:
        """分析普通用户画像"""
        # 筛选易用性高的产品（低门槛、有UI、描述简单）
        casual_keywords = ['easy', 'simple', 'ui', 'gui', 'webui', 'chat', 'interface']
        casual_products = []
        
        for p in products:
            desc = (p.get('description', '') + ' ' + p.get('tagline', '')).lower()
            topics = p.get('topics', [])
            if isinstance(topics, str):
                try:
                    topics = json.loads(topics)
                except:
                    topics = []
            
            if any(kw in desc for kw in casual_keywords) or 'ui' in topics or 'chat' in topics:
                casual_products.append(p)
        
        return {
            'name': '普通用户',
            'description': '非技术背景，希望快速使用AI能力的终端用户',
            'size': '超大型',
            'characteristics': [
                '无需编程知识',
                '重视界面体验',
                '希望即开即用',
                '价格敏感'
            ],
            'pain_points': [
                '技术门槛高',
                '配置复杂',
                '缺乏使用指导',
                '效果不稳定'
            ],
            'needs': [
                '简洁的界面',
                '详细的使用教程',
                '免费或低价版本',
                '稳定的服务质量'
            ],
            'sample_products': [p['name'] for p in casual_products[:5]] if casual_products else ['Open WebUI', 'stable-diffusion-webui']
        }
    
    def _analyze_enterprise_users(self, products: List[Dict]) -> Dict:
        """分析企业用户画像"""
        # 筛选企业级产品（高stars、有特定企业标签）
        enterprise_products = []
        
        for p in products:
            topics = p.get('topics', [])
            if isinstance(topics, str):
                try:
                    topics = json.loads(topics)
                except:
                    topics = []
            
            if any(t in topics for t in ['enterprise', 'production', 'scalable']):
                enterprise_products.append(p)
        
        return {
            'name': '企业级用户',
            'description': '需要大规模部署、高可用性、完整解决方案的大型企业',
            'size': '小型',
            'characteristics': [
                '预算充足',
                '重视稳定性和可靠性',
                '需要完整解决方案',
                '有专门的IT团队'
            ],
            'pain_points': [
                '系统集成复杂',
                '安全合规要求高',
                '需要定制化开发',
                '供应商锁定风险'
            ],
            'needs': [
                '私有化部署',
                '完整的API和SDK',
                '专业的实施服务',
                '长期的技术支持'
            ],
            'sample_products': [p['name'] for p in enterprise_products[:5]] if enterprise_products else ['LangChain', 'transformers']
        }
    
    def generate_persona_report(self) -> str:
        """生成用户画像报告（Markdown格式）"""
        if not self.personas:
            self.generate_personas()
        
        report = f"""# 👥 目标用户画像分析报告

> 生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

---

"""
        
        for key, persona in self.personas.items():
            if key == 'generated_at':
                continue
            
            report += f"""## {persona['name']}

**描述**: {persona['description']}

**用户规模**: {persona['size']}

### 📌 核心特征

"""
            for char in persona['characteristics']:
                report += f"- {char}\n"
            
            report += f"""
### 😫 痛点

"""
            for pain in persona['pain_points']:
                report += f"- {pain}\n"
            
            report += f"""
### 💡 需求

"""
            for need in persona['needs']:
                report += f"- {need}\n"
            
            if 'tech_preferences' in persona:
                report += f"""
### 🛠️ 技术偏好

"""
                for tech, count in persona['tech_preferences']:
                    report += f"- {tech}: {count} 个项目\n"
            
            if 'sample_products' in persona:
                report += f"""
### 📦 代表性产品

{', '.join(persona['sample_products'])}

"""
            report += "---\n\n"
        
        return report
    
    def save_persona_report(self, filepath: str = None) -> str:
        """保存用户画像报告"""
        if filepath is None:
            filepath = f"data/user_personas_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md"
        
        report = self.generate_persona_report()
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(report)
        
        print(f"✅ 用户画像报告已保存: {filepath}")
        return filepath
    
    def get_target_user_summary(self) -> str:
        """获取目标用户摘要（一句话总结）"""
        if not self.personas:
            self.generate_personas()
        
        summaries = []
        for key, persona in self.personas.items():
            if key == 'generated_at':
                continue
            summaries.append(f"{persona['name']}({persona['size']})")
        
        return " → ".join(summaries)


# 便捷函数
def generate_user_personas(db_path: str = "data/products.db") -> Dict:
    """快速生成用户画像"""
    profiler = UserProfiler(db_path)
    return profiler.generate_personas()


# 测试
if __name__ == "__main__":
    profiler = UserProfiler()
    personas = profiler.generate_personas()
    
    if personas:
        print("\n👥 用户画像生成完成!")
        print(f"目标用户: {profiler.get_target_user_summary()}")
        
        # 保存报告
        report_path = profiler.save_persona_report()
        print(f"\n详细报告: {report_path}")
    else:
        print("⚠️ 请先在数据库中添加产品数据")
