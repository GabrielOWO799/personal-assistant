"""
数据导出模块
支持Excel、CSV、JSON等多种格式导出
"""

import json
import csv
import os
from datetime import datetime
from typing import List, Dict


class DataExporter:
    """数据导出器"""
    
    def __init__(self, data: List[Dict] = None):
        self.data = data or []
        self.export_dir = "data/exports"
        os.makedirs(self.export_dir, exist_ok=True)
    
    def load_data(self, filepath: str):
        """从JSON文件加载数据"""
        with open(filepath, 'r', encoding='utf-8') as f:
            self.data = json.load(f)
    
    def export_to_csv(self, filename: str = None) -> str:
        """导出为CSV格式"""
        if filename is None:
            filename = f"competitor_data_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        
        filepath = os.path.join(self.export_dir, filename)
        
        if not self.data:
            print("没有数据可导出")
            return ""
        
        # 获取所有可能的字段
        fieldnames = set()
        for item in self.data:
            fieldnames.update(item.keys())
        
        # 定义字段顺序（重要字段在前）
        priority_fields = ['name', 'platform', 'description', 'url', 'stars', 'forks', 
                          'language', 'category', 'scraped_at']
        other_fields = sorted([f for f in fieldnames if f not in priority_fields])
        fieldnames = priority_fields + other_fields
        
        with open(filepath, 'w', encoding='utf-8', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            
            for item in self.data:
                # 处理列表类型的字段（如topics）
                row = {}
                for key in fieldnames:
                    value = item.get(key, '')
                    if isinstance(value, list):
                        row[key] = ', '.join(str(v) for v in value)
                    else:
                        row[key] = value
                writer.writerow(row)
        
        print(f"✅ CSV导出成功: {filepath}")
        return filepath
    
    def export_to_excel(self, filename: str = None) -> str:
        """导出为Excel格式（需要openpyxl）"""
        try:
            import openpyxl
            from openpyxl.styles import Font, PatternFill, Alignment
            from openpyxl.utils import get_column_letter
        except ImportError:
            print("⚠️ 未安装openpyxl，正在安装...")
            import subprocess
            subprocess.run(['pip3', 'install', 'openpyxl', '-q'])
            import openpyxl
            from openpyxl.styles import Font, PatternFill, Alignment
            from openpyxl.utils import get_column_letter
        
        if filename is None:
            filename = f"competitor_data_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
        
        filepath = os.path.join(self.export_dir, filename)
        
        if not self.data:
            print("没有数据可导出")
            return ""
        
        # 创建工作簿
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "竞品数据"
        
        # 定义表头
        headers = ['项目名称', '平台', '描述', '链接', 'Star数', 'Fork数', 
                   '语言', '分类', '抓取时间', '标签']
        
        # 写入表头
        for col, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col, value=header)
            cell.font = Font(bold=True, color="FFFFFF")
            cell.fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
            cell.alignment = Alignment(horizontal="center", vertical="center")
        
        # 写入数据
        for row_idx, item in enumerate(self.data, 2):
            ws.cell(row=row_idx, column=1, value=item.get('name', ''))
            ws.cell(row=row_idx, column=2, value=item.get('platform', ''))
            ws.cell(row=row_idx, column=3, value=item.get('description', '')[:100] + '...' if len(item.get('description', '')) > 100 else item.get('description', ''))
            ws.cell(row=row_idx, column=4, value=item.get('url', ''))
            ws.cell(row=row_idx, column=5, value=item.get('stars', 0))
            ws.cell(row=row_idx, column=6, value=item.get('forks', 0))
            ws.cell(row=row_idx, column=7, value=item.get('language', ''))
            ws.cell(row=row_idx, column=8, value=item.get('category', ''))
            ws.cell(row=row_idx, column=9, value=item.get('scraped_at', '')[:19] if item.get('scraped_at') else '')
            
            topics = item.get('topics', [])
            if isinstance(topics, list):
                ws.cell(row=row_idx, column=10, value=', '.join(topics[:5]))
            else:
                ws.cell(row=row_idx, column=10, value=str(topics))
        
        # 调整列宽
        column_widths = [20, 20, 50, 40, 12, 12, 12, 15, 20, 40]
        for i, width in enumerate(column_widths, 1):
            ws.column_dimensions[get_column_letter(i)].width = width
        
        # 冻结首行
        ws.freeze_panes = 'A2'
        
        # 保存
        wb.save(filepath)
        print(f"✅ Excel导出成功: {filepath}")
        return filepath
    
    def export_summary_json(self, analysis_data: Dict, filename: str = None) -> str:
        """导出分析摘要JSON"""
        if filename is None:
            filename = f"analysis_summary_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        filepath = os.path.join(self.export_dir, filename)
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(analysis_data, f, ensure_ascii=False, indent=2)
        
        print(f"✅ 分析摘要导出成功: {filepath}")
        return filepath
    
    def export_all(self, analysis_data: Dict = None):
        """导出所有格式"""
        print("\n" + "="*50)
        print("📤 开始导出数据")
        print("="*50)
        
        exported_files = []
        
        # 导出CSV
        csv_file = self.export_to_csv()
        if csv_file:
            exported_files.append(csv_file)
        
        # 导出Excel
        excel_file = self.export_to_excel()
        if excel_file:
            exported_files.append(excel_file)
        
        # 导出分析摘要
        if analysis_data:
            json_file = self.export_summary_json(analysis_data)
            exported_files.append(json_file)
        
        print("\n" + "="*50)
        print(f"✅ 导出完成！共 {len(exported_files)} 个文件")
        print("="*50)
        
        for f in exported_files:
            print(f"  📄 {os.path.basename(f)}")
        
        return exported_files


# 使用示例
if __name__ == "__main__":
    import glob
    
    # 加载最新数据
    data_files = glob.glob("data/combined_competitor_data_*.json")
    if data_files:
        latest_file = max(data_files)
        
        exporter = DataExporter()
        exporter.load_data(latest_file)
        
        # 导出所有格式
        exporter.export_all()
    else:
        print("未找到数据文件")
