"""
PRD生成器模块
基于产品想法自动生成PRD框架
"""

from datetime import datetime
from typing import Dict, List, Optional
import json


class PRDGenerator:
    """PRD文档生成器"""
    
    def __init__(self):
        self.template = self._load_template()
    
    def _load_template(self) -> str:
        """加载PRD模板"""
        return """# {product_name} - 产品需求文档 (PRD)

> 文档版本：v1.0  
> 创建时间：{created_at}  
> 产品负责人：{pm_name}

---

## 1. 产品概述

### 1.1 产品背景
{product_background}

### 1.2 产品目标
{product_goals}

### 1.3 目标用户
{target_users}

### 1.4 核心价值主张
{value_proposition}

---

## 2. 需求分析

### 2.1 用户痛点
{user_pain_points}

### 2.2 需求列表
{requirements}

---

## 3. 功能规划

### 3.1 功能列表
{features}

### 3.2 功能优先级
{feature_priority}

---

## 4. 竞品分析
{competitor_analysis}

---

## 5. 数据指标

### 5.1 核心指标
{core_metrics}

### 5.2 成功标准
{success_criteria}

---

## 6. 时间规划
{timeline}

---

## 7. 风险评估
{risk_assessment}

---

*文档由AI产品需求分析工具自动生成*
"""

    def generate(
        self,
        product_name: str,
        product_idea: str,
        pm_name: str = "待定",
        target_users: str = "",
        pain_points: str = ""
    ) -> str:
        """
        生成PRD文档
        
        Args:
            product_name: 产品名称
            product_idea: 产品想法/描述
            pm_name: 产品经理姓名
            target_users: 目标用户描述
            pain_points: 用户痛点
            
        Returns:
            PRD文档内容
        """
        # 基于产品想法自动生成各部分内容
        context = {
            "product_name": product_name,
            "created_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
            "pm_name": pm_name,
            "product_background": self._generate_background(product_idea),
            "product_goals": self._generate_goals(product_idea),
            "target_users": target_users or self._generate_target_users(product_idea),
            "value_proposition": self._generate_value_proposition(product_idea),
            "user_pain_points": pain_points or self._generate_pain_points(product_idea),
            "requirements": self._generate_requirements(product_idea),
            "features": self._generate_features(product_idea),
            "feature_priority": self._generate_feature_priority(),
            "competitor_analysis": "待补充竞品分析数据...",
            "core_metrics": self._generate_metrics(),
            "success_criteria": "待定义成功标准...",
            "timeline": "待制定时间规划...",
            "risk_assessment": "待评估风险..."
        }
        
        return self.template.format(**context)
    
    def _generate_background(self, idea: str) -> str:
        """生成产品背景"""
        return f"""随着AI技术的快速发展，{idea}成为当前市场的重要需求。

本产品旨在通过AI技术解决用户在{idea}场景下的痛点，提供更智能、更高效的解决方案。

市场机会：
- AI技术应用逐渐成熟
- 用户需求日益增长
- 竞品尚未形成垄断"""
    
    def _generate_goals(self, idea: str) -> str:
        """生成产品目标"""
        return f"""短期目标（1-3个月）：
- 完成MVP版本开发
- 验证核心功能价值
- 获取首批种子用户

中期目标（3-6个月）：
- 完善产品功能
- 提升用户体验
- 扩大用户规模

长期目标（6-12个月）：
- 成为{idea}领域的领先产品
- 建立用户口碑和品牌认知
- 实现商业化盈利"""
    
    def _generate_target_users(self, idea: str) -> str:
        """生成目标用户"""
        return f"""主要用户群体：

1. **核心用户**（占比60%）
   - 年龄：25-35岁
   - 职业：互联网从业者、白领
   - 特征：对新技术敏感，追求效率

2. **次要用户**（占比30%）
   - 年龄：35-45岁
   - 职业：企业中高层管理者
   - 特征：关注ROI，决策谨慎

3. **潜在用户**（占比10%）
   - 学生、自由职业者等"""
    
    def _generate_value_proposition(self, idea: str) -> str:
        """生成价值主张"""
        return f"""**一句话描述**：
通过AI技术，让用户在{idea}场景下获得10倍效率提升。

**核心价值**：
1. **智能化** - AI自动处理，减少人工操作
2. **高效率** - 大幅缩短完成任务的时间
3. **易用性** - 简洁的交互，低学习成本
4. **个性化** - 根据用户习惯智能调整"""
    
    def _generate_pain_points(self, idea: str) -> str:
        """生成用户痛点"""
        return f"""1. **效率低下**
   - 现状：人工处理{idea}相关任务耗时耗力
   - 影响：每天浪费2-3小时在无意义重复工作上

2. **门槛较高**
   - 现状：需要专业知识才能做好{idea}
   - 影响：普通用户难以获得专业级结果

3. **成本昂贵**
   - 现状：请专业人士处理{idea}费用高昂
   - 影响：个人/小团队难以承担"""
    
    def _generate_requirements(self, idea: str) -> str:
        """生成需求列表"""
        return """| 需求ID | 需求描述 | 优先级 | 类型 |
|--------|----------|--------|------|
| R001 | 核心功能：AI自动处理 | P0 | 功能 |
| R002 | 用户注册与登录 | P0 | 功能 |
| R003 | 数据导入导出 | P1 | 功能 |
| R004 | 历史记录查看 | P1 | 功能 |
| R005 | 个性化设置 | P2 | 功能 |
| R006 | 多平台支持 | P2 | 功能 |"""
    
    def _generate_features(self, idea: str) -> str:
        """生成功能列表"""
        return """#### MVP功能（第一阶段）

1. **AI核心功能** ⭐
   - 自动识别和处理
   - 智能推荐和优化
   - 实时反馈和修正

2. **用户系统**
   - 注册/登录
   - 个人中心
   - 基础设置

3. **数据管理**
   - 上传/下载
   - 历史记录
   - 批量操作

#### 迭代功能（第二阶段）

4. **高级功能**
   - API接口
   - 团队协作
   - 数据分析

5. **增值服务**
   - 专业版功能
   - 定制化服务
   - 技术支持"""
    
    def _generate_feature_priority(self) -> str:
        """生成功能优先级"""
        return """**Kano模型分类**：

| 功能 | 类型 | 优先级 | 说明 |
|------|------|--------|------|
| AI核心处理 | 必备 | P0 | 产品核心价值 |
| 用户登录 | 必备 | P0 | 基础功能 |
| 历史记录 | 期望 | P1 | 提升体验 |
| 个性化 | 期望 | P2 | 差异化竞争 |
| 社交分享 | 魅力 | P3 | 锦上添花 |"""
    
    def _generate_metrics(self) -> str:
        """生成数据指标"""
        return """**北极星指标**：
- 日活跃用户数 (DAU)

**核心指标**：
- 用户留存率（次日/7日/30日）
- 功能使用率
- 任务完成率
- 用户满意度 (NPS)

**运营指标**：
- 新增用户数
- 用户获取成本 (CAC)
- 用户生命周期价值 (LTV)"""
    
    def save_to_file(self, prd_content: str, filename: str) -> str:
        """保存PRD到文件"""
        filepath = f"data/{filename}"
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(prd_content)
        return filepath


# 简单的使用示例
if __name__ == "__main__":
    generator = PRDGenerator()
    
    # 示例：生成一个AI写作助手的PRD
    prd = generator.generate(
        product_name="AI写作助手",
        product_idea="帮助用户快速生成高质量文章内容的AI工具",
        pm_name="乌尔达拉克",
        target_users="",
        pain_points=""
    )
    
    print(prd)
    
    # 保存到文件
    filepath = generator.save_to_file(prd, "prd_ai_writing_assistant.md")
    print(f"\nPRD已保存到: {filepath}")
