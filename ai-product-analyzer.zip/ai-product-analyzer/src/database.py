"""
SQLite数据库模块
实现数据持久化、去重和全量覆盖更新
"""

import sqlite3
import json
from datetime import datetime
from typing import List, Dict, Optional
from contextlib import contextmanager


class ProductDatabase:
    """产品数据库管理类"""
    
    def __init__(self, db_path: str = "data/products.db"):
        self.db_path = db_path
        self._init_database()
    
    @contextmanager
    def _get_connection(self):
        """获取数据库连接上下文管理器"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        except Exception as e:
            conn.rollback()
            raise e
        finally:
            conn.close()
    
    def _init_database(self):
        """初始化数据库表结构"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            
            # 主表：产品信息
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS products (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    platform TEXT NOT NULL,
                    tagline TEXT,
                    description TEXT,
                    url TEXT,
                    category TEXT,
                    votes INTEGER DEFAULT 0,
                    stars INTEGER DEFAULT 0,
                    forks INTEGER DEFAULT 0,
                    comments INTEGER DEFAULT 0,
                    language TEXT,
                    topics TEXT,  -- JSON格式存储
                    makers TEXT,  -- JSON格式存储
                    full_name TEXT,
                    author TEXT,
                    created_at TEXT,
                    updated_at TEXT,
                    scraped_at TEXT NOT NULL,
                    raw_data TEXT,  -- 原始JSON数据
                    UNIQUE(name, platform) ON CONFLICT REPLACE
                )
            ''')
            
            # 索引：加速查询
            cursor.execute('''
                CREATE INDEX IF NOT EXISTS idx_products_name 
                ON products(name)
            ''')
            cursor.execute('''
                CREATE INDEX IF NOT EXISTS idx_products_platform 
                ON products(platform)
            ''')
            cursor.execute('''
                CREATE INDEX IF NOT EXISTS idx_products_category 
                ON products(category)
            ''')
            cursor.execute('''
                CREATE INDEX IF NOT EXISTS idx_products_scraped_at 
                ON products(scraped_at)
            ''')
            
            # 统计表：记录每次抓取摘要
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS scrape_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    scrape_time TEXT NOT NULL,
                    total_count INTEGER DEFAULT 0,
                    new_count INTEGER DEFAULT 0,
                    updated_count INTEGER DEFAULT 0,
                    platforms TEXT,  -- JSON格式
                    details TEXT
                )
            ''')
            
            print(f"✅ 数据库初始化完成: {self.db_path}")
    
    def insert_products(self, products: List[Dict]) -> Dict:
        """
        批量插入产品数据（全量覆盖模式）
        
        Args:
            products: 产品数据列表
            
        Returns:
            操作统计信息
        """
        if not products:
            return {'inserted': 0, 'updated': 0, 'total': 0}
        
        inserted = 0
        updated = 0
        platforms = set()
        
        with self._get_connection() as conn:
            cursor = conn.cursor()
            
            for product in products:
                # 提取字段
                name = product.get('name', '')
                platform = product.get('platform', 'Unknown')
                platforms.add(platform)
                
                # 检查是否已存在（用于统计）
                cursor.execute(
                    'SELECT id FROM products WHERE name = ? AND platform = ?',
                    (name, platform)
                )
                existing = cursor.fetchone()
                
                if existing:
                    updated += 1
                else:
                    inserted += 1
                
                # 准备数据
                data = {
                    'name': name,
                    'platform': platform,
                    'tagline': product.get('tagline', ''),
                    'description': product.get('description', '') or product.get('full_name', ''),
                    'url': product.get('url', ''),
                    'category': product.get('category', ''),
                    'votes': self._parse_int(product.get('votes')),
                    'stars': self._parse_int(product.get('stars')),
                    'forks': self._parse_int(product.get('forks')),
                    'comments': self._parse_int(product.get('comments')),
                    'language': product.get('language', ''),
                    'topics': json.dumps(product.get('topics', []), ensure_ascii=False),
                    'makers': json.dumps(product.get('makers', []), ensure_ascii=False),
                    'full_name': product.get('full_name', ''),
                    'author': product.get('author', ''),
                    'created_at': product.get('created_at', ''),
                    'updated_at': product.get('updated_at', ''),
                    'scraped_at': product.get('scraped_at', datetime.now().isoformat()),
                    'raw_data': json.dumps(product, ensure_ascii=False)
                }
                
                # 插入或替换（全量覆盖）
                cursor.execute('''
                    INSERT OR REPLACE INTO products 
                    (name, platform, tagline, description, url, category, 
                     votes, stars, forks, comments, language, topics, makers,
                     full_name, author, created_at, updated_at, scraped_at, raw_data)
                    VALUES 
                    (:name, :platform, :tagline, :description, :url, :category,
                     :votes, :stars, :forks, :comments, :language, :topics, :makers,
                     :full_name, :author, :created_at, :updated_at, :scraped_at, :raw_data)
                ''', data)
            
            # 记录抓取日志
            log_data = {
                'scrape_time': datetime.now().isoformat(),
                'total_count': len(products),
                'new_count': inserted,
                'updated_count': updated,
                'platforms': json.dumps(list(platforms), ensure_ascii=False),
                'details': f'Inserted: {inserted}, Updated: {updated}'
            }
            cursor.execute('''
                INSERT INTO scrape_logs 
                (scrape_time, total_count, new_count, updated_count, platforms, details)
                VALUES 
                (:scrape_time, :total_count, :new_count, :updated_count, :platforms, :details)
            ''', log_data)
        
        result = {
            'inserted': inserted,
            'updated': updated,
            'total': len(products),
            'platforms': list(platforms)
        }
        
        print(f"✅ 数据写入完成: 新增 {inserted} 条, 更新 {updated} 条, 总计 {len(products)} 条")
        return result
    
    def _parse_int(self, value) -> int:
        """安全解析整数"""
        if value is None:
            return 0
        if isinstance(value, int):
            return value
        if isinstance(value, str):
            # 移除可能的逗号和文本
            cleaned = value.replace(',', '').replace('votes', '').replace('stars', '').strip()
            try:
                return int(cleaned)
            except ValueError:
                return 0
        return 0
    
    def get_all_products(self, limit: int = None) -> List[Dict]:
        """
        获取所有产品数据
        
        Args:
            limit: 限制返回数量
            
        Returns:
            产品列表
        """
        with self._get_connection() as conn:
            cursor = conn.cursor()
            
            query = 'SELECT * FROM products ORDER BY scraped_at DESC'
            if limit:
                query += f' LIMIT {limit}'
            
            cursor.execute(query)
            rows = cursor.fetchall()
            
            return [self._row_to_dict(row) for row in rows]
    
    def get_products_by_platform(self, platform: str) -> List[Dict]:
        """按平台获取产品"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                'SELECT * FROM products WHERE platform = ? ORDER BY scraped_at DESC',
                (platform,)
            )
            rows = cursor.fetchall()
            return [self._row_to_dict(row) for row in rows]
    
    def get_products_by_category(self, category: str) -> List[Dict]:
        """按分类获取产品"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                'SELECT * FROM products WHERE category = ? ORDER BY scraped_at DESC',
                (category,)
            )
            rows = cursor.fetchall()
            return [self._row_to_dict(row) for row in rows]
    
    def search_products(self, keyword: str) -> List[Dict]:
        """搜索产品（名称、描述、标签）"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT * FROM products 
                WHERE name LIKE ? OR tagline LIKE ? OR description LIKE ?
                ORDER BY scraped_at DESC
            ''', (f'%{keyword}%', f'%{keyword}%', f'%{keyword}%'))
            rows = cursor.fetchall()
            return [self._row_to_dict(row) for row in rows]
    
    def get_product_by_name(self, name: str) -> Optional[Dict]:
        """根据名称获取产品（跨平台去重）"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                'SELECT * FROM products WHERE name = ? ORDER BY scraped_at DESC LIMIT 1',
                (name,)
            )
            row = cursor.fetchone()
            return self._row_to_dict(row) if row else None
    
    def get_statistics(self) -> Dict:
        """获取数据库统计信息"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            
            # 总数量
            cursor.execute('SELECT COUNT(*) FROM products')
            total = cursor.fetchone()[0]
            
            # 平台分布
            cursor.execute('''
                SELECT platform, COUNT(*) as count 
                FROM products 
                GROUP BY platform
            ''')
            platforms = {row[0]: row[1] for row in cursor.fetchall()}
            
            # 分类分布
            cursor.execute('''
                SELECT category, COUNT(*) as count 
                FROM products 
                GROUP BY category
            ''')
            categories = {row[0]: row[1] for row in cursor.fetchall()}
            
            # 最新抓取时间
            cursor.execute('SELECT MAX(scraped_at) FROM products')
            latest = cursor.fetchone()[0]
            
            # 抓取历史统计
            cursor.execute('SELECT COUNT(*) FROM scrape_logs')
            scrape_count = cursor.fetchone()[0]
            
            return {
                'total_products': total,
                'platforms': platforms,
                'categories': categories,
                'latest_scrape': latest,
                'total_scrapes': scrape_count
            }
    
    def get_scrape_history(self, limit: int = 10) -> List[Dict]:
        """获取抓取历史记录"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT * FROM scrape_logs 
                ORDER BY scrape_time DESC 
                LIMIT ?
            ''', (limit,))
            rows = cursor.fetchall()
            return [dict(row) for row in rows]
    
    def clear_all_data(self):
        """清空所有数据（慎用）"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('DELETE FROM products')
            cursor.execute('DELETE FROM scrape_logs')
            print("⚠️ 数据库已清空")
    
    def _row_to_dict(self, row: sqlite3.Row) -> Dict:
        """将数据库行转换为字典"""
        if not row:
            return {}
        
        result = dict(row)
        
        # 解析JSON字段
        for field in ['topics', 'makers']:
            if field in result and result[field]:
                try:
                    result[field] = json.loads(result[field])
                except json.JSONDecodeError:
                    result[field] = []
        
        # 解析raw_data
        if 'raw_data' in result and result['raw_data']:
            try:
                result['raw_data'] = json.loads(result['raw_data'])
            except json.JSONDecodeError:
                pass
        
        return result
    
    def export_to_json(self, filepath: str = None) -> str:
        """导出所有数据到JSON文件"""
        if filepath is None:
            filepath = f"data/db_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        products = self.get_all_products()
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(products, f, ensure_ascii=False, indent=2)
        
        print(f"✅ 数据已导出到: {filepath}")
        return filepath


# 便捷函数
def get_db(db_path: str = "data/products.db") -> ProductDatabase:
    """获取数据库实例"""
    return ProductDatabase(db_path)


# 测试代码
if __name__ == "__main__":
    # 初始化数据库
    db = ProductDatabase()
    
    # 测试数据
    test_products = [
        {
            'name': 'Test AI Product',
            'platform': 'Test Platform',
            'tagline': 'A test product',
            'description': 'This is a test',
            'url': 'https://example.com',
            'category': 'AI Product',
            'votes': 100,
            'stars': 500,
            'topics': ['AI', 'Test'],
            'scraped_at': datetime.now().isoformat()
        }
    ]
    
    # 插入数据
    result = db.insert_products(test_products)
    print(f"插入结果: {result}")
    
    # 查询统计
    stats = db.get_statistics()
    print(f"\n数据库统计: {json.dumps(stats, ensure_ascii=False, indent=2)}")
    
    # 查询所有数据
    products = db.get_all_products()
    print(f"\n查询到 {len(products)} 条数据")
    
    # 清理测试数据
    db.clear_all_data()
