"""
Selenium浏览器抓取模块
使用浏览器自动化绕过反爬机制
"""

import json
import time
from datetime import datetime
from typing import List, Dict, Optional
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service


class SeleniumScraper:
    """Selenium浏览器抓取器"""
    
    def __init__(self, headless: bool = True):
        self.headless = headless
        self.driver = None
        self.data = []
        self._init_driver()
    
    def _init_driver(self):
        """初始化Chrome浏览器"""
        try:
            chrome_options = Options()
            
            if self.headless:
                chrome_options.add_argument('--headless')
            
            chrome_options.add_argument('--no-sandbox')
            chrome_options.add_argument('--disable-dev-shm-usage')
            chrome_options.add_argument('--disable-gpu')
            chrome_options.add_argument('--window-size=1920,1080')
            chrome_options.add_argument('--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36')
            
            # 禁用图片加载，加快速度
            chrome_options.add_experimental_option("prefs", {
                "profile.managed_default_content_settings.images": 2
            })
            
            # 指定Chromium浏览器路径（Linux环境）
            chrome_options.binary_location = '/usr/bin/chromium-browser'
            
            # 设置ChromeDriver路径环境变量
            import os
            os.environ['PATH'] = '/usr/local/bin:' + os.environ.get('PATH', '')
            
            self.driver = webdriver.Chrome(executable_path='/usr/local/bin/chromedriver', options=chrome_options)
            self.driver.set_page_load_timeout(30)
            
        except Exception as e:
            print(f"Chrome驱动初始化失败: {e}")
            print("请确保已安装Chrome浏览器和ChromeDriver")
            self.driver = None
    
    def scrape_product_hunt(self, max_items: int = 10) -> List[Dict]:
        """
        抓取Product Hunt首页产品
        
        Args:
            max_items: 最大抓取数量
            
        Returns:
            产品列表
        """
        if not self.driver:
            print("浏览器未初始化")
            return []
        
        results = []
        
        try:
            print("正在打开Product Hunt...")
            self.driver.get("https://www.producthunt.com/")
            
            # 等待页面加载
            time.sleep(3)
            
            # 查找产品卡片
            products = self.driver.find_elements(By.CSS_SELECTOR, '[data-test="product-item"]')
            
            print(f"找到 {len(products)} 个产品")
            
            for product in products[:max_items]:
                try:
                    name = product.find_element(By.CSS_SELECTOR, 'h2').text
                    tagline = product.find_element(By.CSS_SELECTOR, '[data-test="product-tagline"]').text
                    votes = product.find_element(By.CSS_SELECTOR, '[data-test="vote-button"]').text
                    
                    results.append({
                        'platform': 'Product Hunt (Selenium)',
                        'name': name,
                        'tagline': tagline,
                        'votes': votes.replace('votes', '').strip(),
                        'category': 'Tech Product',
                        'scraped_at': datetime.now().isoformat()
                    })
                except:
                    continue
                    
        except Exception as e:
            print(f"Product Hunt抓取失败: {e}")
            
        return results
    
    def scrape_github_trending(self, max_items: int = 10) -> List[Dict]:
        """
        抓取GitHub Trending页面
        
        Args:
            max_items: 最大抓取数量
            
        Returns:
            项目列表
        """
        if not self.driver:
            print("浏览器未初始化")
            return []
        
        results = []
        
        try:
            print("正在打开GitHub Trending...")
            self.driver.get("https://github.com/trending/python?since=daily")
            
            # 等待页面加载
            time.sleep(3)
            
            # 查找项目列表
            repos = self.driver.find_elements(By.CSS_SELECTOR, 'article.Box-row')
            
            print(f"找到 {len(repos)} 个项目")
            
            for repo in repos[:max_items]:
                try:
                    name = repo.find_element(By.CSS_SELECTOR, 'h2 a').text
                    description = repo.find_element(By.CSS_SELECTOR, 'p').text if repo.find_elements(By.CSS_SELECTOR, 'p') else ''
                    
                    # 过滤AI相关项目
                    if any(keyword in description.lower() for keyword in ['ai', 'artificial', 'machine learning', 'llm', 'chatbot']):
                        stars = repo.find_element(By.CSS_SELECTOR, 'a[href*="stargazers"]').text if repo.find_elements(By.CSS_SELECTOR, 'a[href*="stargazers"]') else '0'
                        
                        results.append({
                            'platform': 'GitHub Trending (Selenium)',
                            'name': name,
                            'description': description,
                            'stars': stars,
                            'category': 'AI Open Source',
                            'scraped_at': datetime.now().isoformat()
                        })
                except:
                    continue
                    
        except Exception as e:
            print(f"GitHub Trending抓取失败: {e}")
            
        return results
    
    def scrape_all(self) -> List[Dict]:
        """
        抓取所有Selenium数据源
        
        Returns:
            所有平台的数据合并列表
        """
        if not self.driver:
            print("浏览器未初始化，无法抓取")
            return []
        
        all_results = []
        
        print("开始Selenium抓取...")
        
        # Product Hunt
        print("  - 抓取Product Hunt...")
        ph_results = self.scrape_product_hunt(max_items=5)
        all_results.extend(ph_results)
        print(f"    获取 {len(ph_results)} 条")
        
        # GitHub Trending
        print("  - 抓取GitHub Trending...")
        gh_results = self.scrape_github_trending(max_items=5)
        all_results.extend(gh_results)
        print(f"    获取 {len(gh_results)} 条")
        
        self.data = all_results
        print(f"\n✅ 共抓取 {len(all_results)} 条数据")
        
        return all_results
    
    def save_to_json(self, filename: str = None) -> str:
        """保存数据为JSON文件"""
        if filename is None:
            filename = f"selenium_competitor_data_{datetime.now().strftime('%Y%m%d')}.json"
        
        filepath = f"data/{filename}"
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(self.data, f, ensure_ascii=False, indent=2)
        
        print(f"数据已保存到: {filepath}")
        return filepath
    
    def close(self):
        """关闭浏览器"""
        if self.driver:
            self.driver.quit()
            print("浏览器已关闭")


# 使用示例
if __name__ == "__main__":
    scraper = SeleniumScraper(headless=True)
    
    if scraper.driver:
        # 抓取数据
        results = scraper.scrape_all()
        
        # 保存数据
        scraper.save_to_json()
        
        # 关闭浏览器
        scraper.close()
    else:
        print("请安装Chrome浏览器和ChromeDriver后再试")
