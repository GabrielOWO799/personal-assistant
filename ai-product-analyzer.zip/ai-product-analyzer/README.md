# AI竞品分析器

🤖 自动抓取和分析AI产品竞品的工具

## 项目结构

```
ai-product-analyzer/
├── src/
│   ├── main.py              # 主入口，整合所有功能
│   ├── api_scraper.py       # API抓取器 (Product Hunt / GitHub)
│   ├── selenium_scraper.py  # Selenium浏览器抓取器
│   └── competitor_scraper.py # 竞品分析模块
├── data/                    # 数据存储目录
├── tests/                   # 测试文件
└── templates/               # 模板文件
```

## 功能模块

### 1. API抓取器 (`api_scraper.py`)
- ✅ **Product Hunt API** - 抓取AI产品信息
- ✅ **GitHub Search API** - 抓取热门AI开源项目
- ✅ **GitHub Trending API** - 抓取今日趋势
- 无需Token即可抓取GitHub公开数据

### 2. Selenium抓取器 (`selenium_scraper.py`)
- ✅ **Product Hunt** - 动态页面抓取
- ✅ **GitHub Trending** - 浏览器模拟访问
- ✅ Chrome/Chromium支持（Linux环境已配置）

### 3. 竞品分析模块 (`competitor_scraper.py`)
- Kickstarter项目抓取
- Indiegogo众筹项目
- 36氪AI硬件资讯
- 自动生成分析报告

### 4. 数据分析模块 (`analytics.py`) ⭐新增
- 技术标签热度分析
- 编程语言分布统计
- Star数分布分析
- 创建时间趋势分析
- 自动生成Markdown报告

### 5. 数据导出模块 (`exporter.py`) ⭐新增
- CSV格式导出
- Excel格式导出（带样式）
- JSON摘要导出

### 6. Web界面 (`web_server.py`) ⭐新增
- 数据可视化仪表板
- 热门项目展示
- 平台/语言分布图表
- 原始数据API接口

## 使用方法

### 安装依赖
```bash
pip3 install selenium requests openpyxl
```

### 运行测试
```bash
python3 src/main.py --test
```

### 仅运行API抓取
```bash
python3 src/main.py --api-only
```

### 完整流程（抓取+分析+导出）
```bash
python3 src/main.py
```

### 使用API Token（可选）
```bash
python3 src/main.py --ph-token YOUR_PH_TOKEN --gh-token YOUR_GH_TOKEN
```

### 启动Web界面
```bash
python3 src/web_server.py [端口]
# 默认端口8080
# 访问 http://localhost:8080
```

### 单独运行功能
```bash
# 仅数据分析
python3 src/analytics.py

# 仅数据导出
python3 src/exporter.py
```

## 当前状态

| 模块 | 状态 | 说明 |
|------|------|------|
| API抓取器 | ✅ 正常 | 已测试通过，可抓取GitHub数据 |
| Selenium抓取器 | ⚠️ 需环境 | 需要安装Chrome和ChromeDriver |
| 竞品分析 | 🔄 待完善 | 基础框架已搭建 |

## 最新测试结果

**2026-04-03**
- ✅ API抓取器: 成功获取15条GitHub热门AI项目
- ⏭️ Selenium抓取器: 跳过（环境未配置）
- 📊 数据已保存至 `data/api_competitor_data_20260403.json`

## 数据示例

抓取的数据包含以下字段：
- `platform`: 数据来源平台
- `name`: 项目名称
- `description`: 项目描述
- `url`: 项目链接
- `stars`: GitHub star数
- `forks`: GitHub fork数
- `topics`: 技术标签
- `category`: 分类
- `scraped_at`: 抓取时间

## 待办事项

- [ ] 配置Chrome环境以启用Selenium抓取
- [ ] 完善竞品分析模块的报告生成功能
- [ ] 添加数据可视化功能
- [ ] 支持更多数据源（TechCrunch、The Verge等）
- [ ] 添加定时任务支持

## 注意事项

1. **频率限制**: 请合理控制抓取频率，避免对目标网站造成压力
2. **API Token**: Product Hunt需要Token才能访问，GitHub公开数据无需Token
3. **数据隐私**: 抓取的数据仅用于分析，请遵守各平台的使用条款
