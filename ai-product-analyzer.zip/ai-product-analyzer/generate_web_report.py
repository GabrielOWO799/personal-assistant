"""生成Web报告"""

import json
import os
from datetime import datetime
from collections import Counter

def generate_web_report():
    # 加载数据
    data_file = 'data/combined_competitor_data_20260403_172318.json'
    with open(data_file, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    # 生成摘要
    platforms = Counter(item.get('platform', 'Unknown') for item in data)
    languages = Counter(item.get('language', 'Unknown') for item in data if item.get('language'))
    
    total_stars = 0
    for item in data:
        try:
            total_stars += int(item.get('stars', 0))
        except:
            pass
    
    summary = {
        'total': len(data),
        'platforms': dict(platforms),
        'languages': dict(languages),
        'total_stars': total_stars
    }
    
    # 生成表格行
    rows = ""
    for item in data:
        stars = item.get('stars', 'N/A')
        forks = item.get('forks', 'N/A')
        language = item.get('language', 'N/A')
        topics = ', '.join(item.get('topics', [])[:5])
        
        rows += f"""
            <tr>
                <td><a href="{item.get('url', '#')}" target="_blank">{item.get('name', 'N/A')}</a></td>
                <td>{item.get('platform', 'N/A')}</td>
                <td>{item.get('description', 'N/A')[:100]}{'...' if len(item.get('description', '')) > 100 else ''}</td>
                <td>⭐ {stars}</td>
                <td>🍴 {forks}</td>
                <td>{language}</td>
                <td>{topics}</td>
            </tr>
            """
    
    # 生成平台分布
    platform_bars = ""
    for platform, count in summary['platforms'].items():
        width = (count / summary['total']) * 100 if summary['total'] > 0 else 0
        platform_bars += f"""
            <div class="bar-item">
                <span class="bar-label">{platform}</span>
                <div class="bar" style="width: {width}%"></div>
                <span class="bar-value">{count}</span>
            </div>
            """
    
    # 生成语言分布
    lang_bars = ""
    for lang, count in summary['languages'].items():
        width = (count / summary['total']) * 100 if summary['total'] > 0 else 0
        lang_bars += f"""
            <div class="bar-item">
                <span class="bar-label">{lang}</span>
                <div class="bar" style="width: {width}%"></div>
                <span class="bar-value">{count}</span>
            </div>
            """
    
    html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🤖 AI竞品分析器</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #f5f7fa; color: #333; line-height: 1.6; }}
        .header {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 2rem; text-align: center; }}
        .header h1 {{ font-size: 2.5rem; margin-bottom: 0.5rem; }}
        .container {{ max-width: 1400px; margin: 0 auto; padding: 2rem; }}
        .stats-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1.5rem; margin-bottom: 2rem; }}
        .stat-card {{ background: white; border-radius: 12px; padding: 1.5rem; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }}
        .stat-card h3 {{ font-size: 0.9rem; color: #666; margin-bottom: 0.5rem; }}
        .stat-card .value {{ font-size: 2rem; font-weight: bold; color: #667eea; }}
        .charts-section {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap: 1.5rem; margin-bottom: 2rem; }}
        .chart-card {{ background: white; border-radius: 12px; padding: 1.5rem; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }}
        .bar-item {{ display: flex; align-items: center; margin-bottom: 0.8rem; }}
        .bar-label {{ width: 200px; font-size: 0.9rem; color: #666; }}
        .bar {{ height: 24px; background: linear-gradient(90deg, #667eea 0%, #764ba2 100%); border-radius: 12px; margin: 0 1rem; min-width: 50px; }}
        .bar-value {{ font-weight: bold; color: #667eea; }}
        .data-table {{ background: white; border-radius: 12px; padding: 1.5rem; box-shadow: 0 2px 8px rgba(0,0,0,0.1); overflow-x: auto; }}
        table {{ width: 100%; border-collapse: collapse; }}
        th, td {{ padding: 0.8rem; text-align: left; border-bottom: 1px solid #eee; }}
        th {{ background: #f8f9fa; font-weight: 600; color: #555; }}
        tr:hover {{ background: #f8f9fa; }}
        a {{ color: #667eea; text-decoration: none; }}
        a:hover {{ text-decoration: underline; }}
        .footer {{ text-align: center; padding: 2rem; color: #999; font-size: 0.9rem; }}
    </style>
</head>
<body>
    <div class="header">
        <h1>🤖 AI竞品分析器</h1>
        <p>自动抓取和分析AI领域热门项目</p>
    </div>
    
    <div class="container">
        <div class="stats-grid">
            <div class="stat-card">
                <h3>📊 总项目数</h3>
                <div class="value">{summary['total']}</div>
            </div>
            <div class="stat-card">
                <h3>⭐ 总Star数</h3>
                <div class="value">{summary['total_stars']:,}</div>
            </div>
            <div class="stat-card">
                <h3>💻 主要语言</h3>
                <div class="value">{list(summary['languages'].keys())[0] if summary['languages'] else 'N/A'}</div>
            </div>
            <div class="stat-card">
                <h3>🕐 更新时间</h3>
                <div class="value" style="font-size: 1rem;">{datetime.now().strftime('%m-%d %H:%M')}</div>
            </div>
        </div>
        
        <div class="charts-section">
            <div class="chart-card">
                <h3>🌐 平台分布</h3>
                {platform_bars}
            </div>
            <div class="chart-card">
                <h3>💻 编程语言分布</h3>
                {lang_bars}
            </div>
        </div>
        
        <div class="data-table">
            <h2>📋 项目列表</h2>
            <table>
                <thead>
                    <tr>
                        <th>项目名称</th>
                        <th>平台</th>
                        <th>描述</th>
                        <th>Stars</th>
                        <th>Forks</th>
                        <th>语言</th>
                        <th>标签</th>
                    </tr>
                </thead>
                <tbody>
                    {rows}
                </tbody>
            </table>
        </div>
    </div>
    
    <div class="footer">
        <p>AI竞品分析器 | 数据自动更新</p>
    </div>
</body>
</html>"""
    
    # 保存HTML文件
    output_file = 'data/web_report.html'
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(html)
    
    print(f"✅ Web报告已生成: {output_file}")
    return output_file

if __name__ == "__main__":
    generate_web_report()
